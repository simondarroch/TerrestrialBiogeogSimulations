################################################################################################################

### 'clean' code mapping diversity in North American mammals under ext. scenarios, and measuring beta diversity

###
rm(list=ls())

### packages
library(maptools)
library(sp)
library(PBSmapping)
library(rgeos)
library(spdep)
library(rgdal)
library(splancs)
library(pastecs)
library(plotrix)
library(raster)
library(geosphere)
library(betapart)

### North American .shps
US_map<-readOGR(dsn = "/Users/darrocsa/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/code/NAmer_shps/NAmer.shp", layer = "NAmer")
US_map_rangeproj<-spTransform(US_map, CRS("+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"))

### North American mammal ranges
mam_data <- readOGR(dsn = "/Users/darrocsa/Desktop/Projects/Range Size Simulations_w.Geography/TERRESTRIAL_MAMMALS/TERRESTRIAL_MAMMALS.shp", layer = "TERRESTRIAL_MAMMALS")
mam_unique <- unique(mam_data@data$scientific)
# mam_clipped<-crop(mam_data, extent(US_map_clipped))

### load up the IUCN list of N. American mammals (N.American_mammals_lim) and extract a vector of names:
mams <- read.csv("~/Desktop/Projects/Range Size Simulations_w.Geography/N.American_mammals_lim.csv")
mam.sp.names <- as.vector(paste(mams$Genus, mams$Species, sep=" "))

# set up an empty list to put subsetted N. American mammals in:
NAtaxa<-list()
counter=1

for (t in 1:length(mam_unique)) {    
    ts<-mam_unique[t]
    tmp<-mam_data[which(mam_data$scientific == ts) , ]
    name<-as.character(tmp$scientific[1])
    # print(name)   
    if (name %in% mam.sp.names == TRUE){    	
    	NAtaxa[[counter]]<-tmp
    	counter=counter+1    	
    }  
    # print(counter)    
}    

### see how many species we have in there...

all_species<-NAtaxa
l.species<-length(all_species)

# get a vector species names
sp.names<-c()

for (smut in 1:length(NAtaxa)){
	t.smut<-NAtaxa[[smut]]
	nm<-t.smut$scientific[1]
	sp.names<-c(sp.names, as.character(nm))
}

# just in case...
# length(all_species)
# all_species2<-all_species[-328] # gets rid of Ursus americanus, which has a corrupt geometry
# l.species2<-length(all_species2)
# l.species2
# sp.names2<-sp.names[-328] # Again...gets rid of Ursus americanus

# time info
ranch<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/pbdb_data/Rancholabrean_trimmed.csv", row.names=1)
rls<-paste(ranch$lat, ranch$lng, sep="&")
urls<-unique(rls)

# now get into a new table
ranch_locals_prelim<-array(NA, dim=c(length(urls), 2))
colnames(ranch_locals_prelim)<-c("lat","long")
for (s in 1:length(urls)){
	turls<-urls[s]
	cs<-strsplit(turls, "&")
	ranch_locals_prelim[s,1]<-as.numeric(cs[[1]][2])
	ranch_locals_prelim[s,2]<-as.numeric(cs[[1]][1])
}

ranch_locals_prelim<-as.data.frame(ranch_locals_prelim)

# take a quick look at the distribution of localities
ft<-cbind(ranch_locals_prelim$lat, ranch_locals_prelim$long)
lc<-coordinates(ft)
frp<-SpatialPointsDataFrame(lc, ranch_locals_prelim, proj4string=CRS("+proj=longlat +datum=WGS84"))
projection(frp)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	

# and plot
# dev.new(height=8, width=8)
# plot(US_map_rangeproj, col="white", axes=T)
# points(frp, pch=21, col="red", bg="red", cex=0.7)
# points(fr, pch=21, col="blue", bg="blue", cex=0.7)

# lastly, we need to crop these by out N. American .shp polygon
cropped_locals<-gIntersection(US_map_rangeproj, frp)

# and re-save as a simple dataframe
cropped_locals.df<-as.data.frame(cropped_locals) # 718 unique localities
ranch_coords<-cropped_locals.df
lc<-coordinates(ranch_coords)
frp<-SpatialPointsDataFrame(lc, ranch_coords, proj4string=CRS("+proj=longlat +datum=WGS84"))
projection(frp)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	
ranch.locals<-nrow(ranch_coords)

# and re-plot
dev.new(height=8, width=8)
plot(US_map_rangeproj, col="white", axes=T)
points(frp, pch=21, col="red", bg="red", cex=0.7)

# taphonomy table
taph.table<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Probabilities_of_preservation.csv", header=T)

# take a quick look at the distribution of probabilities...
prob.distr<-taph.table[order(taph.table$CorrProb) , ]
plot(prob.distr$CorrProb)

# make a probability vector
prob.vec<-seq(0, 1, by=0.01)

# lagerstatten vector
lager.vec<-seq(0.01, 1, by=0.01)

# load body masses
body.mass.table<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Elton_traits1.0.csv")
attach(body.mass.table)

# owl pellet size threshold
pellet.large.thresh<-800 # set max. prey mammal size
pellet.small.thresh<-5 # set min. prey mammal size

################################################################################################################

### get baseline results

# color schemes
trans.red <- rgb(255, 0, 0, max = 255, alpha = 2, names = "transred")
richness.cols<-colorRampPalette(c("white","forest green","yellow","orange"), alpha=TRUE)(400)
richness.cols2<-heat.colors(100, alpha = 0.4)

# grid resolution
gridres<-1

# raster list
raster.list<-list()

# make a results array
baseline_array<-array(NA, dim=c(l.species, 1))
rownames(baseline_array)<-c(as.character(sp.names))
colnames(baseline_array)<-c("chull (km2)")

# loop
for (j in 1:l.species){
		
	c.species<-all_species[[j]]
	projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the ranges in the right projection
	cl.species<-gIntersection(US_map_rangeproj, c.species)
	
	if (is.null(cl.species)) { 			
				
		print(paste(c.species$scientific[1], "IS NULL", sep = "  "))
			
		} else {	
			
		r.species<-spTransform(cl.species, CRS("+proj=cea +lat_ts=30"))	
		r.species.a<-gArea(r.species)
		res<-paste(c.species$scientific[1], r.species.a/10^6, "km2", sep=" ")
		print(res)
		
		# stash range area into baseline array
		baseline_array[j,1]<-r.species.a/10^6
		
		# try some funky raster stuff
		# make a raster
		raz<-raster(ncol=360/gridres, nrow=180/gridres, xmn=-180, xmx=180, ymn=-90, ymx=90)
		raz <-setValues(raz, c(0))
		raz.fix<-rasterize(cl.species, raz, fun='sum', background=NA, mask=FALSE, update=FALSE, updateValue='all', filename="", getCover=FALSE, silent=TRUE)
		
		# put in raster list
		raster.list[j]<-raz.fix
	
	}
	
}

# stack rasters
raster.list2 <- raster.list[-which(sapply(raster.list, is.null))]
s <- raster::stack(raster.list2)
class(s)
datasum<-stackApply(s, indices=1, fun = sum)

# save the csv.
write.csv(baseline_array, "baseline_ranges.csv")

# and plot if you need to
dev.new(height=8, width=8)
plot(US_map_rangeproj, axes=T, xlim=c(-160, -40), ylim=c(10,90))
rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col = "white")
plot(US_map_rangeproj, col="white", add=T)
plot(datasum, col=richness.cols, zlim=c(0,90), add=T)

################################################################################################################

### Sequentially remove 25%, 50% and 75% smallest-ranged taxa, and re-map diversity

# get baseline data
baseline<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/baseline_ranges.csv")

# get rid of NAs and sort by size
baseline<-baseline[!is.na(baseline$chull..km2.) , ]
baseline<-baseline[order(baseline$chull..km2.) , ]

# Remove smallest ranges...by quartiles
# baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

# record the species list
trimmed.list<-c(as.character(baseline.trimmed$X))

### now adapt the loop so we only sample these larger-ranged species

# grid resolution
gridres<-1

# raster list
raster.list<-list()

# loop
for (j in 1:l.species){
		
	c.species<-all_species[[j]]
	c.species.name<-c.species$scientific[1]
	
	if (c.species.name %in% trimmed.list) {
	
	projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
	cl.species<-gIntersection(US_map_rangeproj, c.species)
	
	if (is.null(cl.species)) { 			
				
		print(paste(c.species$scientific[1], "IS NULL", sep = "  "))
			
		} else {	
			
		r.species<-spTransform(cl.species, CRS("+proj=cea +lat_ts=30"))	
		r.species.a<-gArea(r.species)
		res<-paste(c.species$scientific[1], r.species.a/10^6, "km2", sep=" ")
		print(res)
		
		# and add to the plot
		# plot(cl.species, col=trans.red, border=trans.red, add=T)
		
		# try some funky raster stuff
		# make a raster
		raz<-raster(ncol=360/gridres, nrow=180/gridres, xmn=-180, xmx=180, ymn=-90, ymx=90)
		raz <-setValues(raz, c(0))
		raz.fix<-rasterize(cl.species, raz, fun='sum', background=NA, mask=FALSE, update=FALSE, updateValue='all', filename="", getCover=FALSE, silent=TRUE)
		
		# put in raster list
		raster.list[j]<-raz.fix
	
		}

	}
	
}

raster.list2 <- raster.list[-which(sapply(raster.list, is.null))]
s <- raster::stack(raster.list2)
class(s)
datasum<- stackApply(s, indices=1, fun = sum)

# plot
dev.new(height=8, width=8)
plot(US_map_rangeproj, axes=T, xlim=c(-160, -40), ylim=c(10,90))
rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col = "white")
plot(US_map_rangeproj, col="white", add=T)
plot(datasum, col=richness.cols, zlim=c(0,90), add=T)

# see how it looks in Albers
albers<-"+proj=aea +lat_1=20 +lat_2=60 +lat_0=40 +lon_0=-96 +x_0=0 +y_0=0 +el"
map_albers<-spTransform(US_map_rangeproj, CRS(albers))
datasum_alb<-projectRaster(datasum, crs=albers)

dev.new(height=8, width=8)
plot(map_albers, axes=T, xlim=c(-4e+06, 3e+06))
rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col = "white")
plot(map_albers, col="white", add=T)
plot(datasum_alb, col=richness.cols, zlim=c(0,90), add=T)

# doesn't look great.

### quantify beta on these 4 maps - REMEMBER TO DO FOR EACH EXTINCTION INTENSITY

# set a grid resolution
gridres<-1

# build a raster
ex.raz<-raster(ncol=360/gridres, nrow=180/gridres, xmn=-180, xmx=180, ymn=-90, ymx=90)

# matrix describing species pres./abs. for all cells in the raster
beta.matrix<-array(0, dim=c(ncell(ex.raz), l.species))
dim(beta.matrix) # 64,800 by 377
colnames(beta.matrix)<-c(sp.names)
# head(beta.matrix)

# Loop: cycle through each species, extract a list of cell numbers that species appears in, and load it into the results table

for (j in 1:l.species){
		
	c.species<-all_species[[j]]
	c.species.name<-c.species$binomial[1]
	
	if (c.species.name %in% trimmed.list) {
	
	projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
	cl.species<-gIntersection(US_map_rangeproj, c.species)
	
	if (is.null(cl.species)) { 			
				
		print(paste(c.species$scientific[1], "IS NULL", sep = "  "))
			
		} else {	
			
		r.species<-spTransform(cl.species, CRS("+proj=cea +lat_ts=30"))	
		r.species.a<-gArea(r.species)
		res<-paste(c.species$scientific[1], r.species.a/10^6, "km2", sep=" ")
		print(res)
		
		# and add to the plot
		# plot(cl.species, col=trans.red, border=trans.red, add=T)
		
		# make a raster
		raz<-raster(ncol=360/gridres, nrow=180/gridres, xmn=-180, xmx=180, ymn=-90, ymx=90)
		raz<-setValues(raz, c(1:ncell(raz)))
		
		# do the extract thing and try and save the cells
		r<-extract(raz, cl.species)
		v<-as.vector(r)[[1]]
		name<-as.character(c.species$scientific[1])
		beta.matrix[c(v) , name]<-1
	
		} # if species has a presence in our N. America polygon
	
	} # if species in trimmed list
	
} # for all species

# get rid of rows that are empty
beta.matrix<-beta.matrix[rowSums(beta.matrix[, -1])>0, ]
# head(beta.matrix)
# dim(beta.matrix)

# save to .csv
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/pres-abs_matrices")
write.csv(beta.matrix, "75_ext.csv") # REMEMBER to CHANGE FILE NAMES

### quantify beta

# load the .csv files
full<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/pres-abs_matrices/0_ext.csv")
trimmed25<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/pres-abs_matrices/25_ext.csv")
trimmed50<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/pres-abs_matrices/50_ext.csv")
trimmed75<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/pres-abs_matrices/75_ext.csv")

# tidy up
full<-full[ , 2:ncol(full)]
trimmed25<-trimmed25[ , 2:ncol(trimmed25)]
trimmed50<-trimmed50[ , 2:ncol(trimmed50)]
trimmed75<-trimmed75[ , 2:ncol(trimmed75)]

# calculate multisite beta
betares1<-beta.multi(full, index.family="sorensen")
betares2<-beta.multi(trimmed25, index.family="sorensen")
betares3<-beta.multi(trimmed50, index.family="sorensen")
betares4<-beta.multi(trimmed75, index.family="sorensen")

# collect and plot
all.multi<-c(betares1$beta.SOR, betares2$beta.SOR, betares3$beta.SOR, betares4$beta.SOR)
plot(all.multi, pch=21, col="black", bg="red", type="b", cex=2)

### and now a prettier plot with right spacing, axes etc.
a<-rnorm(50, mean=5, sd=0.01)
b<-rnorm(50, mean=5, sd=0.01)
c<-rnorm(50, mean=5, sd=0.01)
d<-rnorm(50, mean=5, sd=0.01)

boxplot(list(a,b,c,d), ylim=c(0.99880, 0.9990), col="white", border="white", notch=T, main="", ylab="Betasim", names=c("0","25","50","75"), boxwex=0.5)
points(all.multi, pch=21, col="black", bg="red", type="b", cex=2)

################################################################################################################

### perform experiments 1 through 5; 'random', 'localities', 'taphonomy', 'lagerstatten', and 'castings'

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/simmed Beta")

################################################################################################################

### 'random'

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results")

# establish baseline and ext. intensity
baseline<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/baseline_ranges.csv")
baseline<-baseline[!is.na(baseline$chull) , ]
baseline<-baseline[order(baseline$chull) , ]
dim(baseline) # 374 rows
baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
# baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

# record the species list
trimmed.list<-c(as.character(baseline.trimmed$X))

# iterations
iter<-100

# sampling 
sites<-300 # repeat for 3, 30, and 300 sites

# results array
sim.beta.array<-array(NA, dim=c(iter, 2))
colnames(sim.beta.array)<-c("beta","alpha")

# loop
for (it in 1:iter){
	
	print(it) # lets keep track
	
	# simulate fossil record
	fr<-spsample(US_map_rangeproj, sites, "random")
	
	# create a pres/abs table
	sp.array<-array(0, dim=c(sites, nrow(baseline.trimmed)))
	# dim(sp.array)
	colnames(sp.array)<-c(as.character(baseline.trimmed$X))
	
	for (j in 1: l.species){
		
		c.species<-all_species[[j]]
		c.species.name<-c.species$scientific[1]
		name<-as.character(c.species.name)
		projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
		cl.species<-gIntersection(US_map_rangeproj, c.species)
		
		if (c.species.name %in% trimmed.list) {
	
			cl.species<-gIntersection(US_map_rangeproj, c.species)
			
			# now see if we can extract from these 'sites'
			exf<-extract(cl.species, fr, buffer=20) # puts a 20 meter buffer around the sampling site
			hits<-exf[ which(exf$poly.ID=="1") , ]
			hit.pts<-as.vector(hits$point.ID)
			sp.array[c(hit.pts) , name]<-1
		
		} # if the species has a presence
	
	} # for all species
	
	# now calculate beta and save in the overall results matrix
	beta.res<-beta.multi(sp.array, index.family="sorensen")
	sim.beta.array[it , 1]<-beta.res$beta.SOR # save beta
	sim.beta.array[it , 2]<-ncol(sp.array[, colSums(sp.array) > 0]) # save alpha
	
	# save .csv
	write.csv(sim.beta.array, "random_0trimmed_30sites.csv")
	
} # for all iterations

################################################################################################################

### 'localities'

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results")

# establish baseline and ext. intensity
baseline<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/baseline_ranges.csv")
baseline<-baseline[!is.na(baseline$chull) , ]
baseline<-baseline[order(baseline$chull) , ]
dim(baseline) # 374 rows
baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
# baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

# record the species list
trimmed.list<-c(as.character(baseline.trimmed$X))

# iterations
iter<-100

# sampling 
sites<-30 # repeat for 3, 30, and 300 sites

# results array
sim.beta.array<-array(NA, dim=c(iter, 2))
colnames(sim.beta.array)<-c("beta","alpha")

# Racholabrean coords
ranch.locals<-nrow(ranch_coords)

# loop
for (it in 1:iter){
	
	print(it) # keep track
	
	# simulate fossil record from the Rancholbrean
	locs_1<-sample(ranch.locals, sites, replace=FALSE)
	locs_2<-ranch_coords[locs_1 , ]
	locs_3<-as.data.frame(locs_2)
	fr<-SpatialPointsDataFrame(locs_2, locs_3, proj4string=CRS("+proj=longlat +datum=WGS84"))
	projection(fr)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	
	
	# create a pres/abs table
	sp.array<-array(0, dim=c(sites, nrow(baseline.trimmed)))
	# dim(sp.array)
	colnames(sp.array)<-c(as.character(baseline.trimmed$X))
	
	for (j in 1: l.species){
		
		c.species<-all_species[[j]]
		c.species.name<-c.species$scientific[1]
		name<-as.character(c.species.name)
		projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
		
		if (c.species.name %in% trimmed.list) {
	
		cl.species<-gIntersection(US_map_rangeproj, c.species)

		# now extract from these 'sites'
		exf<-extract(cl.species, fr, buffer=20) # puts a 20 meter buffer around the sampling site
		hits<-exf[ which(exf$poly.ID=="1") , ]
		hit.pts<-as.vector(hits$point.ID)
		sp.array[c(hit.pts) , name]<-1
				
		} # if the species is in our trimmed list
	
	} # for all species
	
	# now calculate beta and save in the overal results matrix
	beta.res<-beta.multi(sp.array, index.family="sorensen")
	alpha.res<-ncol(sp.array[, colSums(sp.array) > 0]) # save alpha
	sim.beta.array[it , 1]<-beta.res$beta.SOR # save beta
	sim.beta.array[it , 2]<-alpha.res
	
	# save .csv
	write.csv(sim.beta.array, "localities_0trimmed_30sites.csv")
	
} # for all iterations

################################################################################################################

### 'taphonomy'

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results")

# establish baseline and ext. intensity
baseline<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/baseline_ranges.csv")
baseline<-baseline[!is.na(baseline$chull) , ]
baseline<-baseline[order(baseline$chull) , ]
dim(baseline) # 374 rows
baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
# baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

# record the species list
trimmed.list<-c(as.character(baseline.trimmed$X))

# iterations
iter<-100

# sampling 
sites<-30

# results array
sim.beta.array<-array(NA, dim=c(iter, 2))
colnames(sim.beta.array)<-c("beta","alpha")

# loop
for (it in 1:iter){
	
	print(it) # lets keep track
	
	# simulate fossil record from the Rancholbrean
	locs_1<-sample(ranch.locals, sites, replace=FALSE)
	locs_2<-ranch_coords[locs_1 , ]
	locs_3<-as.data.frame(locs_2)
	fr<-SpatialPointsDataFrame(locs_2, locs_3, proj4string=CRS("+proj=longlat +datum=WGS84"))
	projection(fr)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"
	
	# create a pres/abs table
	sp.array<-array(0, dim=c(sites, nrow(baseline.trimmed)))
	# dim(sp.array)
	colnames(sp.array)<-c(as.character(baseline.trimmed$X))
	
	for (j in 1: l.species){
		
		c.species<-all_species[[j]]
		c.species.name<-c.species$scientific[1]
		name<-as.character(c.species.name)
		projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
		cl.species<-gIntersection(US_map_rangeproj, c.species)
		
		if (c.species.name %in% trimmed.list) {
			
		### now the taphonomy part
		
		this.species<-taph.table[ which(taph.table$X == name) , ]
		this.species.prob<-this.species[,3]
		
		# extract from these 'sites'				
		exf<-extract(cl.species, fr, buffer=20) # puts a 20 meter buffer around the sampling site	
		hits<-exf[ which(exf$poly.ID=="1") , ]
		hit.pts<-as.vector(hits$point.ID)
		
		# now go through the hit points, and roll the dice for each one
		for (hp in 1:length(hit.pts)){
			
			this.hp<-hit.pts[hp]
			prob<-sample(prob.vec, 1)
			
			# let's take a look at this...should ideally get a mixture of TRUE and FALSE
			print(paste(name, prob, this.species.prob, prob <= this.species.prob, sep="  "))
			
			# now generate the 'if' clause
			if (prob <= this.species.prob) {

				sp.array[this.hp , name]<-1
			
				} # only if the species is 'found'
		
			} # for all hit points
		
		} # if the species is in the trimmed list
	
	} # for all species
	
	# now calculate beta and save in the overal results matrix
	beta.res<-beta.multi(sp.array, index.family="sorensen")
	sim.beta.array[it , 1]<-beta.res$beta.SOR # save beta
	# sim.beta.array[it , 2]<-ncol(sp.array[, colSums(sp.array) > 0]) # save alpha
	
	# and then...just for the 3's
	if (ncol(as.matrix(sp.array[, colSums(sp.array) > 0])) > 0) {
	
		sim.beta.array[it , 2]<-ncol(as.matrix(sp.array[, colSums(sp.array) > 0]))
	
	}
	
	# save .csv
	write.csv(sim.beta.array, "taphonomy_0trimmed_30sites.csv")
	
} # for all iterations

################################################################################################################

### 'lagerstatten'

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results")

# establish baseline and ext. intensity
baseline<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/baseline_ranges.csv")
baseline<-baseline[!is.na(baseline$chull) , ]
baseline<-baseline[order(baseline$chull) , ]
dim(baseline) # 374 rows
baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
# baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

# record the species list
trimmed.list<-c(as.character(baseline.trimmed$X))

# iterations
iter<-100

# sampling 
sites<-30

# results array
sim.beta.array<-array(NA, dim=c(iter, 2))
colnames(sim.beta.array)<-c("beta","alpha")

# loop
for (it in 1:iter){
	
	print(it) # lets keep track
	
	# simulate fossil record from the Rnacholabrean
	locs_1<-sample(ranch.locals, sites, replace=FALSE)
	locs_2<-ranch_coords[locs_1 , ]
	locs_3<-as.data.frame(locs_2)
	fr<-SpatialPointsDataFrame(locs_2, locs_3, proj4string=CRS("+proj=longlat +datum=WGS84"))
	projection(fr)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	
	
	# create a pres/abs table
	sp.array<-array(0, dim=c(sites, nrow(baseline.trimmed)))
	# dim(sp.array)
	colnames(sp.array)<-c(as.character(baseline.trimmed$X))
	
	#################################################################################
	
	# now the lagerstatten clause	
	for (pot.lagerstatten in 1:length(fr)){
		
		this.pot.site<-locs_3[pot.lagerstatten , ]
		
		# roll the lagerstatten dice
		lager.prob<-sample(lager.vec, 1)
		print(paste(pot.lagerstatten, lager.prob), sep="  &  ")
		
		if (lager.prob == 1.00){
			
			print("LAGERSTATTEN!!!")
			
			for (ll in 1:l.species){
		
			l.c.species<-all_species[[ll]]
			l.c.species.name<-l.c.species$scientific[1]
			l.name<-as.character(l.c.species.name)
			projection(l.c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
			l.cl.species<-gIntersection(US_map_rangeproj, l.c.species)
		
			if (l.c.species.name %in% trimmed.list) {
				
				lag<-as.data.frame(this.pot.site)
				lagerstatten<-SpatialPointsDataFrame(this.pot.site, lag, proj4string=CRS("+proj=longlat +datum=WGS84"))
				projection(lagerstatten)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"
				exf<-extract(l.cl.species, lagerstatten, buffer=20) # puts a 20 meter buffer around the sampling site
				exf[is.na(exf)] <- 0 # we need to find a way to find out if the locality 'hits' the species in question
				
				if (exf$poly.ID >= 1){
					
						sp.array[pot.lagerstatten, l.name]<-1 # get them in there
					
					}

				} # if it's in the trimmed species list
				
			} # for all species in the list
			
		} # if the site is a lagerstatten
		
	} # for all fossil localities in this iteration
	
	# rowSums(sp.array)
	# colSums(sp.array)
	
	#################################################################################
	
	for (j in 1: l.species){
		
		c.species<-all_species[[j]]
		c.species.name<-c.species$scientific[1]
		name<-as.character(c.species.name)
		projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
		cl.species<-gIntersection(US_map_rangeproj, c.species)
		
		if (c.species.name %in% trimmed.list) {
			
		### now the taphonomy part
		
		this.species<-taph.table[ which(taph.table$X == name) , ]
		this.species.prob<-this.species[,3]
		
		# now see if we can extract from these 'sites'				
		exf<-extract(cl.species, fr, buffer=20) # puts a 20 meter buffer around the sampling site	
		hits<-exf[ which(exf$poly.ID=="1") , ]
		hit.pts<-as.vector(hits$point.ID)
		
		# now we go through the hit points, and roll the dice for each one
		for (hp in 1:length(hit.pts)){
			
			this.hp<-hit.pts[hp]
			prob<-sample(prob.vec, 1)
			
			# let's take a look at this...should ideally get a mixture of TRUE and FALSE
			# print(paste(name, prob, this.species.prob, prob <= this.species.prob, sep="  "))
			
			# now generate the 'if' clause
			if (prob <= this.species.prob) {

				sp.array[this.hp , name]<-1
			
				} # only if the species is 'found'
		
			} # for all hit points
		
		} # if the species is in the trimmed list
	
	} # for all species
	
	#################################################################################
	
	# now calculate beta and save in the overal results matrix
	beta.res<-beta.multi(sp.array, index.family="sorensen")
	sim.beta.array[it , 1]<-beta.res$beta.SOR # save beta
	# sim.beta.array[it , 2]<-ncol(sp.array[, colSums(sp.array) > 0]) # save alpha
	
	# and then...just for the 3's
	if (ncol(as.matrix(sp.array[, colSums(sp.array) > 0])) > 0) {
	
		sim.beta.array[it , 2]<-ncol(as.matrix(sp.array[, colSums(sp.array) > 0]))
	
	}
	
	# save .csv
	write.csv(sim.beta.array, "lagerstatten_0trimmed_30sites.csv")
	
} # for all iterations

################################################################################################################

### 'castings'

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results")

# establish baseline and ext. intensity
baseline<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/baseline_ranges.csv")
baseline<-baseline[!is.na(baseline$chull) , ]
baseline<-baseline[order(baseline$chull) , ]
dim(baseline) # 374 rows
baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
# baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

# record the species list
trimmed.list<-c(as.character(baseline.trimmed$X))

# iterations
iter<-100

# sampling 
sites<-30

# results array
sim.beta.array<-array(NA, dim=c(iter, 2))
colnames(sim.beta.array)<-c("beta","alpha")

# loop
for (it in 1:iter){
	
	print(it) # lets keep track
	
	# simulate 300 site fossil record from the Wasatchian
	locs_1<-sample(ranch.locals, sites, replace=FALSE)
	locs_2<-ranch_coords[locs_1 , ]
	locs_3<-as.data.frame(locs_2)
	fr<-SpatialPointsDataFrame(locs_2, locs_3, proj4string=CRS("+proj=longlat +datum=WGS84"))
	projection(fr)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	
	
	# create a pres/abs table
	sp.array<-array(0, dim=c(sites, nrow(baseline.trimmed)))
	# dim(sp.array)
	colnames(sp.array)<-c(as.character(baseline.trimmed$X))
	
	#################################################################################
	
	# now...I think we do the lagerstatten thing here - get it out of the way with...	
	for (pot.lagerstatten in 1:length(fr)){
		
		this.pot.site<-locs_3[pot.lagerstatten , ]
		
		# roll the lagerstatten dice
		lager.prob<-sample(lager.vec, 1)
		print(paste(pot.lagerstatten, lager.prob), sep="  &  ")
		
		if (lager.prob == 1.00){
			
			print("LAGERSTATTEN!!!")
			
			for (ll in 1:l.species){
		
			l.c.species<-all_species[[ll]]
			l.c.species.name<-l.c.species$scientific[1]
			l.name<-as.character(l.c.species.name)
			projection(l.c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
			l.cl.species<-gIntersection(US_map_rangeproj, l.c.species)
		
			if (l.c.species.name %in% trimmed.list) {
				
				lag<-as.data.frame(this.pot.site)
				lagerstatten<-SpatialPointsDataFrame(this.pot.site, lag, proj4string=CRS("+proj=longlat +datum=WGS84"))
				projection(lagerstatten)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"
				exf<-extract(l.cl.species, lagerstatten, buffer=20) # puts a 20 meter buffer around the sampling site
				exf[is.na(exf)] <- 0 # we need to find a way to find out if the locality 'hits' the species in question
				
				if (exf$poly.ID >= 1){
					
						sp.array[pot.lagerstatten, l.name]<-1 # get them in there
					
					}

				} # if it's in the trimmed species list
				
			} # for all species in the list
			
		} # if the site is a lagerstatten
		
	} # for all fossil localities in this iteration
	
	# rowSums(sp.array)
	# colSums(sp.array)
	
	#################################################################################
	
	for (j in 1: l.species){
		
		c.species<-all_species[[j]]
		c.species.name<-c.species$scientific[1]
		name<-as.character(c.species.name)
		projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
		cl.species<-gIntersection(US_map_rangeproj, c.species)
		
		if (c.species.name %in% trimmed.list) {
			
		### now the taphonomy part
		
		this.species<-taph.table[ which(taph.table$X == name) , ]
		this.species.prob<-this.species[,3]
		
		# now see if we can extract from these 'sites'				
		exf<-extract(cl.species, fr, buffer=20) # puts a 20 meter buffer around the sampling site	
		hits<-exf[ which(exf$poly.ID=="1") , ]
		hit.pts<-as.vector(hits$point.ID)
		
		# now we go through the hit points, and roll the dice for each one
		for (hp in 1:length(hit.pts)){
			
			this.hp<-hit.pts[hp]
			prob<-sample(prob.vec, 1)
			
			# let's take a look at this...should ideally get a mixture of TRUE and FALSE
			# print(paste(name, prob, this.species.prob, prob <= this.species.prob, sep="  "))
			
			# now generate the 'if' clauses
			if (prob <= this.species.prob) {

				sp.array[this.hp , name]<-1
			
				} # only if the species is 'found'
		
			} # for all hit points
			
		# now we put in the owl pellet stuff, much in the same fashion
		for (hhp in 1:length(hit.pts)){
			
			this.hhp<-hit.pts[hhp]
			this.body.mass.data<-body.mass.table[ which(body.mass.table$Species == as.character(c.species.name)) , ]
			this.body.mass<-as.numeric(this.body.mass.data[26]) # make sure body mass is in the 26th column
			
			# now generate the 'if' clauses
			if (this.body.mass <= pellet.large.thresh & this.body.mass >= pellet.small.thresh) {

				sp.array[this.hhp , name]<-1
			
				} # only if the species is small/large enough to be owl bait
		
			} # for all hit points
		
		} # if the species is in the trimmed list
	
	} # for all species
	
	#################################################################################
	
	# now calculate beta and save in the overal results matrix
	beta.res<-beta.multi(sp.array, index.family="sorensen")
	sim.beta.array[it , 1]<-beta.res$beta.SOR # save beta
	# sim.beta.array[it , 2]<-ncol(sp.array[, colSums(sp.array) > 0]) # save alpha
	
	# and then...just for the 3's
	if (ncol(as.matrix(sp.array[, colSums(sp.array) > 0])) > 0) {
	
		sim.beta.array[it , 2]<-ncol(as.matrix(sp.array[, colSums(sp.array) > 0]))
	
	}
	
	# save .csv
	write.csv(sim.beta.array, "castings_0trimmed_30sites.csv")
	
} # for all iterations

################################################################################################################

### now we need to do three more sensitivity tests, building off the 'castings' experiments

# 1. Need to remove the largest, rather than smallest-ranged species
# 2. Need to simulate random extinctions
# 3. Need to simulate range expansions

################################################################################################################

### Begin with 1: largest ranged species, first establishing baselines

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/large_baselines")

# get baseline data
baseline<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/baseline_ranges.csv")

# get rid of NAs and sort by size
baseline<-baseline[!is.na(baseline$chull..km2.) , ]
baseline<-baseline[order(-baseline$chull..km2.) , ] # note that the '-' here is reordering species so that largest ranges come at the top

### Sequentially remove 25%, 50% and 75% smallest-ranged taxa, and re-map diversity

# Remove largest ranges...by quartiles
# baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

# record the species list
trimmed.list<-c(as.character(baseline.trimmed$X))

### now adapt the loop so we only sample these smaller-ranged species

# grid resolution
gridres<-1

# raster list
raster.list<-list()

# set a grid resolution
gridres<-1

# build a raster
ex.raz<-raster(ncol=360/gridres, nrow=180/gridres, xmn=-180, xmx=180, ymn=-90, ymx=90)

# matrix describing species pres./abs. for all cells in the raster
beta.matrix<-array(0, dim=c(ncell(ex.raz), l.species))
dim(beta.matrix) # 64,800 by 377
colnames(beta.matrix)<-c(sp.names)
# head(beta.matrix)

# Loop: cycle through each species, extract a list of cell numbers that species appears in, and load it into the results table
for (j in 1:l.species){
		
	c.species<-all_species[[j]]
	c.species.name<-c.species$binomial[1]
	
	if (c.species.name %in% trimmed.list) {
	
	projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
	cl.species<-gIntersection(US_map_rangeproj, c.species)
	
	if (is.null(cl.species)) { 			
				
		print(paste(c.species$scientific[1], "IS NULL", sep = "  "))
			
		} else {	
			
		r.species<-spTransform(cl.species, CRS("+proj=cea +lat_ts=30"))	
		r.species.a<-gArea(r.species)
		res<-paste(c.species$scientific[1], r.species.a/10^6, "km2", sep=" ")
		print(res)
		
		# and add to the plot
		# plot(cl.species, col=trans.red, border=trans.red, add=T)
		
		# make a raster
		raz<-raster(ncol=360/gridres, nrow=180/gridres, xmn=-180, xmx=180, ymn=-90, ymx=90)
		raz<-setValues(raz, c(1:ncell(raz)))
		
		# do the extract thing and try and save the cells
		r<-extract(raz, cl.species)
		v<-as.vector(r)[[1]]
		name<-as.character(c.species$scientific[1])
		beta.matrix[c(v) , name]<-1
	
		} # if species has a presence in our N. America polygon
	
	} # if species in trimmed list
	
} # for all species

# get rid of rows that are empty
beta.matrix<-beta.matrix[rowSums(beta.matrix[, -1])>0, ]
# head(beta.matrix)
# dim(beta.matrix)

# save to .csv
write.csv(beta.matrix, "0_ext_large.csv") # REMEMBER to CHANGE FILE NAMES

### quantify beta

# load the .csv files
trimmed0<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/large_baselines/0_ext_large.csv")
trimmed25<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/large_baselines/25_ext_large.csv")
trimmed50<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/large_baselines/50_ext_large.csv")
trimmed75<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/large_baselines/75_ext_large.csv")

# tidy up
trimmed0<-trimmed0[ , 2:ncol(trimmed0)]
trimmed25<-trimmed25[ , 2:ncol(trimmed25)]
trimmed50<-trimmed50[ , 2:ncol(trimmed50)]
trimmed75<-trimmed75[ , 2:ncol(trimmed75)]

# calculate multisite beta
betares1<-beta.multi(trimmed0, index.family="sorensen")
betares2<-beta.multi(trimmed25, index.family="sorensen")
betares3<-beta.multi(trimmed50, index.family="sorensen")
betares4<-beta.multi(trimmed75, index.family="sorensen")

# collect and plot
all.multi<-c(betares1$beta.SOR, betares2$beta.SOR, betares3$beta.SOR, betares4$beta.SOR)
plot(all.multi, pch=21, col="black", bg="red", type="b", cex=2)

### re-perform experiment 5 'castings'

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results")

# get baseline data
baseline<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/baseline_ranges.csv")

# get rid of NAs and sort by size
baseline<-baseline[!is.na(baseline$chull..km2.) , ]
baseline<-baseline[order(-baseline$chull..km2.) , ] # note that the '-' here is reordering species so that largest ranges come at the top

### Sequentially remove 25%, 50% and 75% smallest-ranged taxa, and re-map diversity

# Remove largest ranges...by quartiles
baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
# baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

# iterations
iter<-100

# sampling 
sites<-300

# results array
sim.beta.array<-array(NA, dim=c(iter, 3))
colnames(sim.beta.array)<-c("beta","alpha","lagerstatten")

# loop
for (it in 1:iter){
	
	print(it) # lets keep track
	
	# simulate 300 site fossil record from the Wasatchian
	locs_1<-sample(ranch.locals, sites, replace=FALSE)
	locs_2<-ranch_coords[locs_1 , ]
	locs_3<-as.data.frame(locs_2)
	fr<-SpatialPointsDataFrame(locs_2, locs_3, proj4string=CRS("+proj=longlat +datum=WGS84"))
	projection(fr)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	
	
	# create a pres/abs table
	sp.array<-array(0, dim=c(sites, nrow(baseline.trimmed)))
	# dim(sp.array)
	colnames(sp.array)<-c(as.character(baseline.trimmed$X))
	
	# set up a counter
	counter=0
	
	#################################################################################
	
	# now...I think we do the lagerstatten thing here - get it out of the way with...	
	for (pot.lagerstatten in 1:length(fr)){
		
		this.pot.site<-locs_3[pot.lagerstatten , ]
		
		# roll the lagerstatten dice
		lager.prob<-sample(lager.vec, 1)
		print(paste(pot.lagerstatten, lager.prob), sep="  &  ")
		
		if (lager.prob == 1.00){
			
			print("LAGERSTATTEN!!!")
			counter=counter+1
			
			for (ll in 1:l.species){
		
			l.c.species<-all_species[[ll]]
			l.c.species.name<-l.c.species$scientific[1]
			l.name<-as.character(l.c.species.name)
			projection(l.c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
			l.cl.species<-gIntersection(US_map_rangeproj, l.c.species)
		
			if (l.c.species.name %in% trimmed.list) {
				
				lag<-as.data.frame(this.pot.site)
				lagerstatten<-SpatialPointsDataFrame(this.pot.site, lag, proj4string=CRS("+proj=longlat +datum=WGS84"))
				projection(lagerstatten)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"
				exf<-extract(l.cl.species, lagerstatten, buffer=20) # puts a 20 meter buffer around the sampling site
				exf[is.na(exf)] <- 0 # we need to find a way to find out if the locality 'hits' the species in question
				
				if (exf$poly.ID >= 1){
					
						sp.array[pot.lagerstatten, l.name]<-1 # get them in there
					
					}

				} # if it's in the trimmed species list
				
			} # for all species in the list
			
		} # if the site is a lagerstatten
		
	} # for all fossil localities in this iteration
	
	# rowSums(sp.array)
	# colSums(sp.array)
	
	#################################################################################
	
	for (j in 1: l.species){
		
		c.species<-all_species[[j]]
		c.species.name<-c.species$scientific[1]
		name<-as.character(c.species.name)
		projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
		cl.species<-gIntersection(US_map_rangeproj, c.species)
		
		if (c.species.name %in% trimmed.list) {
			
		### now the taphonomy part
		
		this.species<-taph.table[ which(taph.table$X == name) , ]
		this.species.prob<-this.species[,3]
		
		# now see if we can extract from these 'sites'				
		exf<-extract(cl.species, fr, buffer=20) # puts a 20 meter buffer around the sampling site	
		hits<-exf[ which(exf$poly.ID=="1") , ]
		hit.pts<-as.vector(hits$point.ID)
		
		# now we go through the hit points, and roll the dice for each one
		for (hp in 1:length(hit.pts)){
			
			this.hp<-hit.pts[hp]
			prob<-sample(prob.vec, 1)
			
			# let's take a look at this...should ideally get a mixture of TRUE and FALSE
			# print(paste(name, prob, this.species.prob, prob <= this.species.prob, sep="  "))
			
			# now generate the 'if' clauses
			if (prob <= this.species.prob) {

				sp.array[this.hp , name]<-1
			
				} # only if the species is 'found'
		
			} # for all hit points
			
		# now we put in the owl pellet stuff, much in the same fashion
		for (hhp in 1:length(hit.pts)){
			
			this.hhp<-hit.pts[hhp]
			this.body.mass.data<-body.mass.table[ which(body.mass.table$Species == as.character(c.species.name)) , ]
			this.body.mass<-as.numeric(this.body.mass.data[26]) # make sure body mass is in the 26th column
			
			# now generate the 'if' clauses
			if (this.body.mass <= pellet.large.thresh & this.body.mass >= pellet.small.thresh) {

				sp.array[this.hhp , name]<-1
			
				} # only if the species is small/large enough to be owl bait
		
			} # for all hit points
		
		} # if the species is in the trimmed list
	
	} # for all species
	
	#################################################################################
	
	# now calculate beta and save in the overal results matrix
	beta.res<-beta.multi(sp.array, index.family="sorensen")
	sim.beta.array[it , 1]<-beta.res$beta.SOR # save beta
	# sim.beta.array[it , 2]<-ncol(sp.array[, colSums(sp.array) > 0]) # save alpha
	
	# and then...just for the 3's
	if (ncol(as.matrix(sp.array[, colSums(sp.array) > 0])) > 0) {
	
		sim.beta.array[it , 2]<-ncol(as.matrix(sp.array[, colSums(sp.array) > 0]))
	
	}
	
	sim.beta.array[it , 3]<-counter # save number of lagerstatten
	
	# save .csv
	write.csv(sim.beta.array, "castings_sensitivity1_0trimmed_300sites.csv")
	
} # for all iterations

################################################################################################################

### Then 2: random extinction, first establishing baselines

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/random_baselines")

# get baseline data
baseline<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/baseline_ranges.csv")

# get rid of NAs and sort by size
baseline<-baseline[!is.na(baseline$chull..km2.) , ]
baseline<-baseline[order(-baseline$chull..km2.) , ] # note that the '-' here is reordering species so that largest ranges come at the top

# baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species' only for 0% extinction threshold

### Sequentially remove 25%, 50% and 75% of randomly-selected taxa, and re-map diversity

# set extinction level
extinction.level<-0 # remember to change

# grid resolution
gridres<-1

# raster list
raster.list<-list()

# set a grid resolution
gridres<-1

# set iterations - for randomly selected taxa, we'll need a vector of beta estimates to costruct the baseline
iter<-100

# set up a beta array to save beta estimates for each randomly-selected set of species
beta.rand.array<-array(NA, dim=c(iter,2))
colnames(beta.rand.array)<-c("beta","gamma") # gamma here should always be the same in baselines, but good to include as a check

# Loop: cycle through each species, extract a list of cell numbers that species appears in, and load it into the results table
for (i in 1:iter){
	
	print(i) # keep track
	
	# now randomly select species based on extinction intensity
	dims<-nrow(baseline)
	dim.ex<-(extinction.level/100)
	dim.lev<-round(dims*dim.ex, 0)
	baseline.lev<-sample(1:nrow(baseline), size=dim.lev, replace=FALSE)
	baseline.trimmed<-baseline[-baseline.lev , ] # remove the randomly-selected species from the trimmed dataset
	dim(baseline.trimmed)
	
	# record the species list
	trimmed.list<-c(as.character(baseline.trimmed$X))
	
	# now build a raster for stashing stuff in
	ex.raz<-raster(ncol=360/gridres, nrow=180/gridres, xmn=-180, xmx=180, ymn=-90, ymx=90)

	# matrix describing species pres./abs. for all cells in the raster
	beta.matrix<-array(0, dim=c(ncell(ex.raz), l.species))
	dim(beta.matrix) # 64,800 by 377
	colnames(beta.matrix)<-c(sp.names)
	
	# now cycle through species
	for (j in 1:l.species){
		
		c.species<-all_species[[j]]
		c.species.name<-c.species$binomial[1]
	
		if (c.species.name %in% trimmed.list) {
	
		projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
		cl.species<-gIntersection(US_map_rangeproj, c.species)
	
			if (is.null(cl.species)) { 			
				
			# print(paste(c.species$scientific[1], "IS NULL", sep = "  "))
			
			} else {	
			
			r.species<-spTransform(cl.species, CRS("+proj=cea +lat_ts=30"))	
			r.species.a<-gArea(r.species)
			res<-paste(c.species$scientific[1], r.species.a/10^6, "km2", sep=" ")
			# print(res)
		
			# and add to the plot
			# plot(cl.species, col=trans.red, border=trans.red, add=T)
		
			# make a raster
			raz<-raster(ncol=360/gridres, nrow=180/gridres, xmn=-180, xmx=180, ymn=-90, ymx=90)
			raz<-setValues(raz, c(1:ncell(raz)))
		
			# do the extract thing and try and save the cells
			r<-extract(raz, cl.species)
			v<-as.vector(r)[[1]]
			name<-as.character(c.species$scientific[1])
			beta.matrix[c(v) , name]<-1
	
			} # if species has a presence in our N. America polygon
	
		} # if species in trimmed list
	
	} # for all species

	# now deal with the beta matrix...first get rid of rows that are empty
	beta.matrix<-beta.matrix[rowSums(beta.matrix[, -1])>0, ]
	
	# then calc. beta for this set of species and stuff in results array
	betares<-beta.multi(beta.matrix, index.family="sorensen")
	beta.rand.array[i,1]<-betares$beta.SOR
	
	# and save gamma
	gammares<-ncol(beta.matrix[, colSums(beta.matrix) > 0])
	beta.rand.array[i,2]<-gammares
	
	# and save the array as we go along
	write.csv(beta.rand.array, "0_ext_random.csv") # REMEMBER to CHANGE FILE NAMES

} # for all iterations

### plot baselines
sensitivity2_0ext<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/random_baselines/0_ext_random.csv", row.names=1)
sensitivity2_25ext<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/random_baselines/25_ext_random.csv", row.names=1)
sensitivity2_50ext<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/random_baselines/50_ext_random.csv", row.names=1)
sensitivity2_75ext<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/random_baselines/75_ext_random.csv", row.names=1)

boxplot(list(sensitivity2_0ext[,1], sensitivity2_25ext[,1], sensitivity2_50ext[,1], sensitivity2_75ext[,1]))

### re-perform experiment 5 'castings'

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/random_baselines")

# get baseline data
baseline<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/baseline_ranges.csv")

# get rid of NAs and sort by size
baseline<-baseline[!is.na(baseline$chull..km2.) , ]
baseline<-baseline[order(-baseline$chull..km2.) , ] # note that the '-' here is reordering species so that largest ranges come at the top

baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species

### Sequentially remove 25%, 50% and 75% of randomly-selected taxa, and re-map diversity

# set extinction level
extinction.level<-25 # remember to change

# grid resolution
gridres<-1

# raster list
raster.list<-list()

# set a grid resolution
gridres<-1

# set iterations - for randomly selected taxa, we'll need a vector of beta estimates to costruct the baseline
iter<-100

# sampling 
sites<-300

# set up a beta array to save beta estimates for each randomly-selected set of species
beta.rand.array<-array(NA, dim=c(iter,3))
colnames(beta.rand.array)<-c("beta","alpha","lagerstatten")

# loop
for (it in 1:iter){
	
	print(it) # lets keep track
	
	# now randomly select species based on extinction intensity
	dims<-nrow(baseline)
	dim.ex<-(extinction.level/100)
	dim.lev<-round(dims*dim.ex, 0)
	baseline.lev<-sample(1:nrow(baseline), size=dim.lev, replace=FALSE)
	baseline.trimmed<-baseline[-baseline.lev , ] # remove the randomly-selected species from the trimmed dataset
	# dim(baseline.trimmed)
	
	# record the species list
	trimmed.list<-c(as.character(baseline.trimmed$X))
	
	# now build a raster for stashing stuff in
	ex.raz<-raster(ncol=360/gridres, nrow=180/gridres, xmn=-180, xmx=180, ymn=-90, ymx=90)

	# matrix describing species pres./abs. for all cells in the raster
	beta.matrix<-array(0, dim=c(ncell(ex.raz), l.species))
	dim(beta.matrix) # 64,800 by 377
	colnames(beta.matrix)<-c(sp.names)

	# now simulate 300 site fossil record
	locs_1<-sample(ranch.locals, sites, replace=FALSE)
	locs_2<-ranch_coords[locs_1 , ]
	locs_3<-as.data.frame(locs_2)
	fr<-SpatialPointsDataFrame(locs_2, locs_3, proj4string=CRS("+proj=longlat +datum=WGS84"))
	projection(fr)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	
	
	# create a pres/abs table
	sp.array<-array(0, dim=c(sites, nrow(baseline.trimmed)))
	# dim(sp.array)
	colnames(sp.array)<-c(as.character(baseline.trimmed$X))
	
	# set up a counter
	counter=0
	
	#################################################################################
	
	# now...I think we do the lagerstatten thing here - get it out of the way with...	
	for (pot.lagerstatten in 1:length(fr)){
		
		this.pot.site<-locs_3[pot.lagerstatten , ]
		
		# roll the lagerstatten dice
		lager.prob<-sample(lager.vec, 1)
		print(paste(pot.lagerstatten, lager.prob), sep="  &  ")
		
		if (lager.prob == 1.00){
			
			print("LAGERSTATTEN!!!")
			counter=counter+1
			
			for (ll in 1:l.species){
		
			l.c.species<-all_species[[ll]]
			l.c.species.name<-l.c.species$scientific[1]
			l.name<-as.character(l.c.species.name)
			projection(l.c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
			l.cl.species<-gIntersection(US_map_rangeproj, l.c.species)
		
			if (l.c.species.name %in% trimmed.list) {
				
				lag<-as.data.frame(this.pot.site)
				lagerstatten<-SpatialPointsDataFrame(this.pot.site, lag, proj4string=CRS("+proj=longlat +datum=WGS84"))
				projection(lagerstatten)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"
				exf<-extract(l.cl.species, lagerstatten, buffer=20) # puts a 20 meter buffer around the sampling site
				exf[is.na(exf)] <- 0 # we need to find a way to find out if the locality 'hits' the species in question
				
				if (exf$poly.ID >= 1){
					
						sp.array[pot.lagerstatten, l.name]<-1 # get them in there
					
					}

				} # if it's in the trimmed species list
				
			} # for all species in the list
			
		} # if the site is a lagerstatten
		
	} # for all fossil localities in this iteration
	
	# rowSums(sp.array)
	# colSums(sp.array)
	
	#################################################################################
	
	for (j in 1: l.species){
		
		c.species<-all_species[[j]]
		c.species.name<-c.species$scientific[1]
		name<-as.character(c.species.name)
		projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
		cl.species<-gIntersection(US_map_rangeproj, c.species)
		
		if (c.species.name %in% trimmed.list) {
			
		### now the taphonomy part
		
		this.species<-taph.table[ which(taph.table$X == name) , ]
		this.species.prob<-this.species[,3]
		
		# now see if we can extract from these 'sites'				
		exf<-extract(cl.species, fr, buffer=20) # puts a 20 meter buffer around the sampling site	
		hits<-exf[ which(exf$poly.ID=="1") , ]
		hit.pts<-as.vector(hits$point.ID)
		
		# now we go through the hit points, and roll the dice for each one
		for (hp in 1:length(hit.pts)){
			
			this.hp<-hit.pts[hp]
			prob<-sample(prob.vec, 1)
			
			# let's take a look at this...should ideally get a mixture of TRUE and FALSE
			# print(paste(name, prob, this.species.prob, prob <= this.species.prob, sep="  "))
			
			# now generate the 'if' clauses
			if (prob <= this.species.prob) {

				sp.array[this.hp , name]<-1
			
				} # only if the species is 'found'
		
			} # for all hit points
			
		# now we put in the owl pellet stuff, much in the same fashion
		for (hhp in 1:length(hit.pts)){
			
			this.hhp<-hit.pts[hhp]
			this.body.mass.data<-body.mass.table[ which(body.mass.table$Species == as.character(c.species.name)) , ]
			this.body.mass<-as.numeric(this.body.mass.data[26]) # make sure body mass is in the 26th column
			
			# now generate the 'if' clauses
			if (this.body.mass <= pellet.large.thresh & this.body.mass >= pellet.small.thresh) {

				sp.array[this.hhp , name]<-1
			
				} # only if the species is small/large enough to be owl bait
		
			} # for all hit points
		
		} # if the species is in the trimmed list
	
	} # for all species
	
	#################################################################################
	
	# now calculate beta and save in the overal results matrix
	beta.res<-beta.multi(sp.array, index.family="sorensen")
	beta.rand.array[it , 1]<-beta.res$beta.SOR # save beta
	# sim.beta.array[it , 2]<-ncol(sp.array[, colSums(sp.array) > 0]) # save alpha
	
	# and then...just for the 3's
	if (ncol(as.matrix(sp.array[, colSums(sp.array) > 0])) > 0) {
	
		beta.rand.array[it , 2]<-ncol(as.matrix(sp.array[, colSums(sp.array) > 0]))
	
	}
	
	beta.rand.array[it , 3]<-counter # save number of lagerstatten
	
	# save .csv
	write.csv(beta.rand.array, "castings_sensitivity2_25trimmed_300sites_1.csv")
	
} # for all iterations

################################################################################################################

### And 3....what we need to do, is simulate 0-75% extinction, and then have 10% of the largest-ranged remaining species undergo range expansion. Need to work out the baselines first

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/expansion_baselines")

# get baseline data
baseline<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/baseline_ranges.csv")

# get rid of NAs and sort by size
baseline<-baseline[!is.na(baseline$chull..km2.) , ]
baseline<-baseline[order(baseline$chull..km2.) , ]

### Sequentially remove 25%, 50% and 75% smallest-ranged taxa, and re-map diversity

# Remove largest ranges...by quartiles
# baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

# record the species list
trimmed.list<-c(as.character(baseline.trimmed$X))

# now work out which species need to have their ranges buffed...we want to do 0, 5, 10 and 20% in ascending order of extinction intensity
exp.perc<-20
buff_nos<-round(nrow(baseline.trimmed)*(exp.perc/100))
buff_lim<-nrow(baseline.trimmed)-buff_nos
buff_taxa<-c(as.character(baseline.trimmed$X[buff_lim:nrow(baseline.trimmed)]))

### now adapt the loop so we only sample these smaller-ranged species

# grid resolution
gridres<-1

# raster list
raster.list<-list()

# build a raster
ex.raz<-raster(ncol=360/gridres, nrow=180/gridres, xmn=-180, xmx=180, ymn=-90, ymx=90)

# matrix describing species pres./abs. for all cells in the raster
beta.matrix<-array(0, dim=c(ncell(ex.raz), l.species))
dim(beta.matrix) # 64,800 by 377
colnames(beta.matrix)<-c(sp.names)
# head(beta.matrix)

# Loop: cycle through each species, extract a list of cell numbers that species appears in, and load it into the results table
for (j in 1:l.species){
		
	c.species<-all_species[[j]]
	c.species.name<-c.species$binomial[1]
	
	if (c.species.name %in% trimmed.list) {
	
	projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
	
	# now deal with the expansion stuff
	if (c.species.name %in% buff_taxa) { cl.species<-gIntersection(US_map_rangeproj, US_map_rangeproj) } # makes the range of 'disaster species' the whole United States	
	else { cl.species<-gIntersection(US_map_rangeproj, c.species) }
	
	# and now move on with the rest of the code
	if (is.null(cl.species)) { 			
				
		print(paste(c.species$scientific[1], "IS NULL", sep = "  "))
			
		} else {	
			
		r.species<-spTransform(cl.species, CRS("+proj=cea +lat_ts=30"))	
		r.species.a<-gArea(r.species)
		res<-paste(c.species$scientific[1], r.species.a/10^6, "km2", sep=" ")
		print(res)
		
		# and add to the plot
		# plot(cl.species, col=trans.red, border=trans.red, add=T)
		
		# make a raster
		raz<-raster(ncol=360/gridres, nrow=180/gridres, xmn=-180, xmx=180, ymn=-90, ymx=90)
		raz<-setValues(raz, c(1:ncell(raz)))
		
		# do the extract thing and try and save the cells
		r<-extract(raz, cl.species)
		v<-as.vector(r)[[1]]
		name<-as.character(c.species$scientific[1])
		beta.matrix[c(v) , name]<-1
	
		} # if species has a presence in our N. America polygon
	
	} # if species in trimmed list
	
} # for all species

# get rid of rows that are empty
beta.matrix<-beta.matrix[rowSums(beta.matrix[, -1])>0, ]
# head(beta.matrix)
# dim(beta.matrix)

# save to .csv
write.csv(beta.matrix, "75_ext_expansion.csv") # REMEMBER to CHANGE FILE NAMES

### quantify beta

# load the .csv files
trimmed0<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/expansion_baselines/0_ext_expansion.csv")
trimmed25<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/expansion_baselines/25_ext_expansion.csv")
trimmed50<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/expansion_baselines/50_ext_expansion.csv")
trimmed75<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/expansion_baselines/75_ext_expansion.csv")

# tidy up
trimmed0<-trimmed0[ , 2:ncol(trimmed0)]
trimmed25<-trimmed25[ , 2:ncol(trimmed25)]
trimmed50<-trimmed50[ , 2:ncol(trimmed50)]
trimmed75<-trimmed75[ , 2:ncol(trimmed75)]

# calculate multisite beta
betares1<-beta.multi(trimmed0, index.family="sorensen")
betares2<-beta.multi(trimmed25, index.family="sorensen")
betares3<-beta.multi(trimmed50, index.family="sorensen")
betares4<-beta.multi(trimmed75, index.family="sorensen")

# collect and plot
all.multi<-c(betares1$beta.SOR, betares2$beta.SOR, betares3$beta.SOR, betares4$beta.SOR)
plot(all.multi, pch=21, col="black", bg="red", type="b", cex=2)

### re-perform experiment 5 'castings'

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/expansion_baselines")

# get baseline data
baseline<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/baseline_ranges.csv")

# Remove largest ranges...by quartiles
# baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

# record the species list
trimmed.list<-c(as.character(baseline.trimmed$X))

# now work out which species need to have their ranges buffed...we want to do 0, 5, 10 and 20% in ascending order of extinction intensity
exp.perc<-20
buff_nos<-round(nrow(baseline.trimmed)*(exp.perc/100))
buff_lim<-nrow(baseline.trimmed)-buff_nos
buff_taxa<-c(as.character(baseline.trimmed$X[buff_lim:nrow(baseline.trimmed)]))

# iterations
iter<-100

# sampling 
sites<-300

# results array
sim.beta.array<-array(NA, dim=c(iter, 3))
colnames(sim.beta.array)<-c("beta","alpha","lagerstatten")

# loop
for (it in 1:iter){
	
	print(it) # lets keep track
	
	# simulate 300 site fossil record from the Rancholabrean
	locs_1<-sample(ranch.locals, sites, replace=FALSE)
	locs_2<-ranch_coords[locs_1 , ]
	locs_3<-as.data.frame(locs_2)
	fr<-SpatialPointsDataFrame(locs_2, locs_3, proj4string=CRS("+proj=longlat +datum=WGS84"))
	projection(fr)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	
	
	# create a pres/abs table
	sp.array<-array(0, dim=c(sites, nrow(baseline.trimmed)))
	# dim(sp.array)
	colnames(sp.array)<-c(as.character(baseline.trimmed$X))
	
	# set up a counter
	counter=0
	
	#################################################################################
	
	# now...I think we do the lagerstatten thing here - get it out of the way with...	
	for (pot.lagerstatten in 1:length(fr)){
		
		this.pot.site<-locs_3[pot.lagerstatten , ]
		
		# roll the lagerstatten dice
		lager.prob<-sample(lager.vec, 1)
		print(paste(pot.lagerstatten, lager.prob), sep="  &  ")
		
		if (lager.prob == 1.00){
			
			print("LAGERSTATTEN!!!")
			counter=counter+1
			
			for (ll in 1:l.species){
		
			l.c.species<-all_species[[ll]]
			l.c.species.name<-l.c.species$scientific[1]
			l.name<-as.character(l.c.species.name)
			projection(l.c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
			
			# now move on to whether it's in the trimmed list
			if (l.c.species.name %in% trimmed.list) {
				
				# now...we need one iteration of the buffing code in here:
				if (l.c.species.name %in% buff_taxa) { l.cl.species<-gIntersection(US_map_rangeproj, US_map_rangeproj) } # makes the range of 'disaster species' the whole United States	
				else { l.cl.species<-gIntersection(US_map_rangeproj, l.c.species) }
				
				# now...we need one more 'if' statement, to get rid of problematic species that fall outside of the NAmer polygon geometry
				if (length(l.cl.species)>0) {
				
				lag<-as.data.frame(this.pot.site)
				lagerstatten<-SpatialPointsDataFrame(this.pot.site, lag, proj4string=CRS("+proj=longlat +datum=WGS84"))
				projection(lagerstatten)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"
				exf<-extract(l.cl.species, lagerstatten, buffer=20) # puts a 20 meter buffer around the sampling site
				exf[is.na(exf)] <- 0 # we need to find a way to find out if the locality 'hits' the species in question
				
				if (exf$poly.ID >= 1){
					
						sp.array[pot.lagerstatten, l.name]<-1 # get them in there
					
						}

					} # if it's in the trimmed species list
				
				} # if it doesn't have a problematic geometry
				
			} # for all species in the list
			
		} # if the site is a lagerstatten
		
	} # for all fossil localities in this iteration
	
	# rowSums(sp.array)
	# colSums(sp.array)
	
	#################################################################################
	
	for (j in 1: l.species){
		
		c.species<-all_species[[j]]
		c.species.name<-c.species$scientific[1]
		name<-as.character(c.species.name)
		projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
	
		if (c.species.name %in% trimmed.list) {
		
		### and now we need to perform this function AGAIN (there must be a better way of doing this...but hey ho)
		if (c.species.name %in% buff_taxa) { cl.species<-gIntersection(US_map_rangeproj, US_map_rangeproj) } # makes the range of 'disaster species' the whole United States	
		else { cl.species<-gIntersection(US_map_rangeproj, c.species) }
		
		### and the stupid 'if' statement here...which seems to be dealing exclusively with Microtus abbreviatus
		if (length(cl.species)>0) {
		
		### now the taphonomy part

		this.species<-taph.table[ which(taph.table$X == name) , ]
		this.species.prob<-this.species[,3]
		
		# now see if we can extract from these 'sites'				
		exf<-extract(cl.species, fr, buffer=20) # puts a 20 meter buffer around the sampling site	
		hits<-exf[ which(exf$poly.ID=="1") , ]
		hit.pts<-as.vector(hits$point.ID)
		
		# now we go through the hit points, and roll the dice for each one
		for (hp in 1:length(hit.pts)){
			
			this.hp<-hit.pts[hp]
			prob<-sample(prob.vec, 1)
			
			# let's take a look at this...should ideally get a mixture of TRUE and FALSE
			# print(paste(name, prob, this.species.prob, prob <= this.species.prob, sep="  "))
			
			# now generate the 'if' clauses
			if (prob <= this.species.prob) {

				sp.array[this.hp , name]<-1
			
				} # only if the species is 'found'
		
			} # for all hit points
			
		# now we put in the owl pellet stuff, much in the same fashion
		for (hhp in 1:length(hit.pts)){
			
			this.hhp<-hit.pts[hhp]
			this.body.mass.data<-body.mass.table[ which(body.mass.table$Species == as.character(c.species.name)) , ]
			this.body.mass<-as.numeric(this.body.mass.data[26]) # make sure body mass is in the 26th column
			
			# now generate the 'if' clauses
			if (this.body.mass <= pellet.large.thresh & this.body.mass >= pellet.small.thresh) {

				sp.array[this.hhp , name]<-1
			
					} # only if the species is small/large enough to be owl bait
		
				} # for all hit points
			
			} # if it falls within the NAmer .shp polygon (M. abbreviatus again)
		
		} # if the species is in the trimmed list
	
	} # for all species
	
	#################################################################################
	
	# now calculate beta and save in the overal results matrix
	beta.res<-beta.multi(sp.array, index.family="sorensen")
	sim.beta.array[it , 1]<-beta.res$beta.SOR # save beta
	# sim.beta.array[it , 2]<-ncol(sp.array[, colSums(sp.array) > 0]) # save alpha
	
	# and then...just for the 3's
	if (ncol(as.matrix(sp.array[, colSums(sp.array) > 0])) > 0) {
	
		sim.beta.array[it , 2]<-ncol(as.matrix(sp.array[, colSums(sp.array) > 0]))
	
	}
	
	sim.beta.array[it , 3]<-counter # save number of lagerstatten
	
	# save .csv
	write.csv(sim.beta.array, "castings_sensitivity3_75trimmed_300sites.csv")
	
} # for all iterations

################################################################################################################

################################################################################################################

### plotting results

# 'random'
random.0.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_0trimmed_3sites.csv")
random.25.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_25trimmed_3sites.csv")
random.50.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_50trimmed_3sites.csv")
random.75.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_75trimmed_3sites.csv")
random.0.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_0trimmed_30sites.csv")
random.25.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_25trimmed_30sites.csv")
random.50.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_50trimmed_30sites.csv")
random.75.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_75trimmed_30sites.csv")
random.0.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_0trimmed_300sites.csv")
random.25.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_25trimmed_300sites.csv")
random.50.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_50trimmed_300sites.csv")
random.75.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_75trimmed_300sites.csv")

### 'localities'
localities.0.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_0trimmed_3sites.csv")
localities.25.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_25trimmed_3sites.csv")
localities.50.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_50trimmed_3sites.csv")
localities.75.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_75trimmed_3sites.csv")
localities.0.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_0trimmed_30sites.csv")
localities.25.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_25trimmed_30sites.csv")
localities.50.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_50trimmed_30sites.csv")
localities.75.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_75trimmed_30sites.csv")
localities.0.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_0trimmed_300sites.csv")
localities.25.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_25trimmed_300sites.csv")
localities.50.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_50trimmed_300sites.csv")
localities.75.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_75trimmed_300sites.csv")

### 'taphonomy'
taphonomy.0.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_0trimmed_3sites.csv")
taphonomy.25.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_25trimmed_3sites.csv")
taphonomy.50.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_50trimmed_3sites.csv")
taphonomy.75.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_75trimmed_3sites.csv")
taphonomy.0.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_0trimmed_30sites.csv")
taphonomy.25.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_25trimmed_30sites.csv")
taphonomy.50.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_50trimmed_30sites.csv")
taphonomy.75.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_75trimmed_30sites.csv")
taphonomy.0.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_0trimmed_300sites.csv")
taphonomy.25.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_25trimmed_300sites.csv")
taphonomy.50.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_50trimmed_300sites.csv")
taphonomy.75.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_75trimmed_300sites.csv")

### 'lagerstatten'
lagerstatten.0.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_0trimmed_3sites.csv")
lagerstatten.25.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_25trimmed_3sites.csv")
lagerstatten.50.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_50trimmed_3sites.csv")
lagerstatten.75.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_75trimmed_3sites.csv")
lagerstatten.0.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_0trimmed_30sites.csv")
lagerstatten.25.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_25trimmed_30sites.csv")
lagerstatten.50.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_50trimmed_30sites.csv")
lagerstatten.75.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_75trimmed_30sites.csv")
lagerstatten.0.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_0trimmed_300sites.csv")
lagerstatten.25.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_25trimmed_300sites.csv")
lagerstatten.50.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_50trimmed_300sites.csv")
lagerstatten.75.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_75trimmed_300sites.csv")

### 'castings'
castings.0.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_0trimmed_3sites.csv")
castings.25.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_25trimmed_3sites.csv")
castings.50.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_50trimmed_3sites.csv")
castings.75.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_75trimmed_3sites.csv")
castings.0.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_0trimmed_30sites.csv")
castings.25.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_25trimmed_30sites.csv")
castings.50.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_50trimmed_30sites.csv")
castings.75.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_75trimmed_30sites.csv")
castings.0.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_0trimmed_300sites.csv")
castings.25.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_25trimmed_300sites.csv")
castings.50.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_50trimmed_300sites.csv")
castings.75.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_75trimmed_300sites.csv")

### produce boxplots
dev.new(height=14, width=10)
par(mar=c(2,4,2,2))
par(mfrow=c(5,3))

### now results of 5 'experiments'

# 'random'
boxplot(c(random.0.3sites[,2]), random.25.3sites[,2], random.50.3sites[,2], random.75.3sites[,2], col="light blue", notch=T, main="3sites_random", ylab="Betasim", names=c("All","25","50","75"), boxwex=0.5)
boxplot(c(random.0.30sites[,2]), random.25.30sites[,2], random.50.30sites[,2], random.75.30sites[,2], col="light blue", notch=T, main="30sites_random", ylab="Betasim", names=c("All","25","50","75"), boxwex=0.5)
boxplot(c(random.0.300sites[,2]), random.25.300sites[,2], random.50.300sites[,2], random.75.300sites[,2], col="light blue", notch=T, main="300sites_random", ylab="Betasim", names=c("All","25","50","75"), boxwex=0.5)

# 'localities'
boxplot(c(localities.0.3sites[,2]), localities.25.3sites[,2], localities.50.3sites[,2], localities.75.3sites[,2], col="light blue", notch=T, main="3sites_localities", ylab="Betasim", names=c("All","25","50","75"), boxwex=0.5)
boxplot(c(localities.0.30sites[,2]), localities.25.30sites[,2], localities.50.30sites[,2], localities.75.30sites[,2], col="light blue", notch=T, main="30sites_localities", ylab="Betasim", names=c("All","25","50","75"), boxwex=0.5)
boxplot(c(localities.0.300sites[,2]), localities.25.300sites[,2], localities.50.300sites[,2], localities.75.300sites[,2], col="light blue", notch=T, main="300sites_localities", ylab="Betasim", names=c("All","25","50","75"), boxwex=0.5)

# 'taphonomy'
boxplot(c(taphonomy.0.3sites[,2]), taphonomy.25.3sites[,2], taphonomy.50.3sites[,2], taphonomy.75.3sites[,2], col="light blue", notch=T, main="3sites_taphonomy", ylab="Betasim", names=c("All","25","50","75"), boxwex=0.5)
boxplot(c(taphonomy.0.30sites[,2]), taphonomy.25.30sites[,2], taphonomy.50.30sites[,2], taphonomy.75.30sites[,2], col="light blue", notch=T, main="30sites_taphonomy", ylab="Betasim", names=c("All","25","50","75"), boxwex=0.5)
boxplot(c(taphonomy.0.300sites[,2]), taphonomy.25.300sites[,2], taphonomy.50.300sites[,2], taphonomy.75.300sites[,2], col="light blue", notch=T, main="300sites_taphonomy", ylab="Betasim", names=c("All","25","50","75"), boxwex=0.5)

# 'lagerstatten'
boxplot(c(lagerstatten.0.3sites[,2]), lagerstatten.25.3sites[,2], lagerstatten.50.3sites[,2], lagerstatten.75.3sites[,2], col="light blue", notch=T, main="3sites_lagerstatten", ylab="Betasim", names=c("All","25","50","75"), boxwex=0.5)
boxplot(c(lagerstatten.0.30sites[,2]), lagerstatten.25.30sites[,2], lagerstatten.50.30sites[,2], lagerstatten.75.30sites[,2], col="light blue", notch=T, main="30sites_lagerstatten", ylab="Betasim", names=c("All","25","50","75"), boxwex=0.5)
boxplot(c(lagerstatten.0.300sites[,2]), lagerstatten.25.300sites[,2], lagerstatten.50.300sites[,2], lagerstatten.75.300sites[,2], col="light blue", notch=T, main="300sites_lagerstatten", ylab="Betasim", names=c("All","25","50","75"), boxwex=0.5)

# 'castings'
boxplot(c(castings.0.3sites[,2]), castings.25.3sites[,2], castings.50.3sites[,2], castings.75.3sites[,2], col="light blue", notch=T, main="3sites_castings", ylab="Betasim", names=c("All","25","50","75"), boxwex=0.5)
boxplot(c(castings.0.30sites[,2]), castings.25.30sites[,2], castings.50.30sites[,2], castings.75.30sites[,2], col="light blue", notch=T, main="30sites_castings", ylab="Betasim", names=c("All","25","50","75"), boxwex=0.5)
boxplot(c(castings.0.300sites[,2]), castings.25.300sites[,2], castings.50.300sites[,2], castings.75.300sites[,2], col="light blue", notch=T, main="300sites_castings", ylab="Betasim", names=c("All","25","50","75"), boxwex=0.5)

################################################################################################################

### plot results of sensitivity tests

# 1. 'large' - large-ranges species go extinct

# first collect and plot baselines
large.0.presabs<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/large_baselines/0_ext_large.csv", row.names=1)
large.25.presabs<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/large_baselines/25_ext_large.csv", row.names=1)
large.50.presabs<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/large_baselines/50_ext_large.csv", row.names=1)
large.75.presabs<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/large_baselines/75_ext_large.csv", row.names=1)

# calculate multisite beta
betares.large.1<-beta.multi(large.0.presabs, index.family="sorensen")
betares.large.2<-beta.multi(large.25.presabs, index.family="sorensen")
betares.large.3<-beta.multi(large.50.presabs, index.family="sorensen")
betares.large.4<-beta.multi(large.75.presabs, index.family="sorensen")

# plot
all.multi.large<-c(betares.large.1$beta.SOR, betares.large.2$beta.SOR, betares.large.3$beta.SOR, betares.large.4$beta.SOR)
plot(all.multi.large, pch=21, col="black", bg="red", type="b", cex=2)

# now collect and plot results
sens1.0.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/large_baselines/castings_sensitivity1_0trimmed_300sites.csv")
sens1.25.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/large_baselines/castings_sensitivity1_25trimmed_300sites.csv")
sens1.50.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/large_baselines/castings_sensitivity1_50trimmed_300sites.csv")
sens1.75.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/large_baselines/castings_sensitivity1_75trimmed_300sites.csv")

boxplot(c(sens1.0.300sites[,2]), sens1.25.300sites[,2], sens1.50.300sites[,2], sens1.75.300sites[,2], col="light blue", notch=T, main="300sites_sens1", ylab="Betasim", names=c("0","25","50","75"), boxwex=0.5)

# finally...use these axes and spacing to produce a prettier baseline plot
boxplot(c(sens1.0.300sites[,2]), sens1.25.300sites[,2], sens1.50.300sites[,2], sens1.75.300sites[,2], ylim=c(0.994, 0.9999), col="white", border="white", notch=T, main="", ylab="Betasim", names=c("0","25","50","75"), boxwex=0.5)
points(all.multi.large, pch=21, col="black", bg="red", type="b", cex=2)

###

# 2. 'random' - extinction selectivity is random

# first collect and plot baselines
random.0.baselines<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/random_baselines/0_ext_random.csv", row.names=1)
random.25.baselines<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/random_baselines/25_ext_random.csv", row.names=1)
random.50.baselines<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/random_baselines/50_ext_random.csv", row.names=1)
random.75.baselines<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/random_baselines/75_ext_random.csv", row.names=1)

# plot
boxplot(c(random.0.baselines[,1]), random.25.baselines[,1],random.50.baselines[,1], random.75.baselines[,1], col="light blue", notch=T, main="", ylab="Betasim", names=c("0","25","50","75"), boxwex=0.5)

# now collect and plot results
sens2.0.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_0trimmed_300sites.csv")
sens2.25.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/random_baselines/castings_sensitivity2_25trimmed_300sites.csv")
sens2.50.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/random_baselines/castings_sensitivity2_50trimmed_300sites.csv")
sens2.75.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/random_baselines/castings_sensitivity2_75trimmed_300sites.csv")

boxplot(c(sens2.0.300sites[,2]), sens2.25.300sites[,2], sens2.50.300sites[,2], sens2.75.300sites[,2], col="light blue", notch=T, main="", ylab="Betasim", names=c("0","25","50","75"), boxwex=0.5)

###

# 3. 'expansion' - surviving species undergo range expansion

# first collect and plot baselines
exp.0.presabs<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/expansion_baselines/0_ext_expansion.csv", row.names=1)
exp.25.presabs<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/expansion_baselines/25_ext_expansion.csv", row.names=1)
exp.50.presabs<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/expansion_baselines/50_ext_expansion.csv", row.names=1)
exp.75.presabs<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/expansion_baselines/75_ext_expansion.csv", row.names=1)

# calculate multisite beta
betares.exp.1<-beta.multi(exp.0.presabs, index.family="sorensen")
betares.exp.2<-beta.multi(exp.25.presabs, index.family="sorensen")
betares.exp.3<-beta.multi(exp.50.presabs, index.family="sorensen")
betares.exp.4<-beta.multi(exp.75.presabs, index.family="sorensen")

# plot
all.multi.exp<-c(betares.exp.1$beta.SOR, betares.exp.2$beta.SOR, betares.exp.3$beta.SOR, betares.exp.4$beta.SOR)
plot(all.multi.exp, pch=21, col="black", bg="red", type="b", cex=2)

# now collect and plot results
sens3.0.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/expansion_baselines/castings_sensitivity3_0trimmed_300sites.csv")
sens3.25.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/expansion_baselines/castings_sensitivity3_25trimmed_300sites.csv")
sens3.50.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/expansion_baselines/castings_sensitivity3_50trimmed_300sites.csv")
sens3.75.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/Sensitivity_tests/expansion_baselines/castings_sensitivity3_75trimmed_300sites.csv")

boxplot(c(sens3.0.300sites[,2]), sens3.25.300sites[,2], sens3.50.300sites[,2], sens3.75.300sites[,2], col="light blue", notch=T, main="", ylab="Betasim", names=c("0","25","50","75"), boxwex=0.5)

# finally...use these axes and spacing to produce a prettier baseline plot
boxplot(c(sens3.0.300sites[,2]), sens3.25.300sites[,2], sens3.50.300sites[,2], sens3.75.300sites[,2], ylim=c(0.9979, 0.9991), col="white", border="white", notch=T, main="", ylab="Betasim", names=c("0","25","50","75"), boxwex=0.5)
points(all.multi.exp, pch=21, col="black", bg="red", type="b", cex=2)

################################################################################################################

### correlations between range size and body size in various scenarios

ranges<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/baseline_ranges.csv")
ETs<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Elton_traits1.0.csv")
probs<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Probabilities_of_preservation.csv")

rs<-ranges$X
new.array<-array(NA, dim=c(length(rs),4))
colnames(new.array)<-c("species","range_km2","mass","presprob")

for (i in 1:length(rs)){
	tsp<-as.character(rs[i])
	trange<-ranges[ which(ranges$X==tsp) , 2]
	tBM<-ETs[ which(ETs$Species==tsp) , 26]
	tprob<-probs[ which(probs$X==tsp) , 3]
	new.array[i,1]<-tsp
	new.array[i,2]<-as.numeric(trange)
	new.array[i,3]<-as.numeric(tBM)
	new.array[i,4]<-as.numeric(tprob)
}

# get rid of NAs
allinfo<-new.array[complete.cases(new.array) , ]
allinfo<-as.data.frame(allinfo)

setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res")
write.csv(allinfo, "allinfo.csv")

# load back in
allinfo<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/allinfo.csv", row.names=1)

# now order, and produce range freq. plots
allinfo<-allinfo[order(-allinfo$range_km2) , ]
hist(allinfo$range_km2, col="light blue")

# remove 25%, 50%, and 75% largest-ranged species
baseline.trimmed.a<-allinfo[1:nrow(allinfo),]
baseline.trimmed.b<-allinfo[94:nrow(allinfo),]
baseline.trimmed.c<-allinfo[187:nrow(allinfo),]
baseline.trimmed.d<-allinfo[280:nrow(allinfo),]

# plot up
dev.new(height=12, width=7)
par(mfcol=c(4,2))
hist(baseline.trimmed.a$range_km2, col="light blue", xlim=c(0,2e07), ylim=c(0,250), xlab="range_km", main="0_trimmed")
hist(baseline.trimmed.b$range_km2, col="light blue", xlim=c(0,2e07), ylim=c(0,250), xlab="range_km", main="25_trimmed")
hist(baseline.trimmed.c$range_km2, col="light blue", xlim=c(0,2e07), ylim=c(0,250), xlab="range_km", main="50_trimmed")
hist(baseline.trimmed.d$range_km2, col="light blue", xlim=c(0,2e07), ylim=c(0,250), xlab="range_km", main="75_trimmed")

plot(baseline.trimmed.a$range_km2, baseline.trimmed.a$mass, pch=19, xlab="range_km", ylab="mass_gm", xlim=c(0,2e07), ylim=c(0,6e05))
plot(baseline.trimmed.b$range_km2, baseline.trimmed.b$mass, pch=19, xlab="range_km", ylab="mass_gm", xlim=c(0,2e07), ylim=c(0,6e05))
plot(baseline.trimmed.c$range_km2, baseline.trimmed.c$mass, pch=19, xlab="range_km", ylab="mass_gm", xlim=c(0,2e07), ylim=c(0,6e05))
plot(baseline.trimmed.d$range_km2, baseline.trimmed.d$mass, pch=19, xlab="range_km", ylab="mass_gm", xlim=c(0,2e07), ylim=c(0,6e05))



################################################################################################################



