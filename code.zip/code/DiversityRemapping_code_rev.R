#################################################################################################################################################################
#################################################################################################################################################################

### 'clean' code for re-plotting and -mapping diversity after simulating fossil records

# set working directory
rm(list=ls())

# packages and data
library(maptools)
library(sp)
library(PBSmapping)
library(rgeos)
library(spdep)
library(rgdal)
library(splancs)
library(pastecs)
library(plotrix)
library(raster)
library(geosphere)
library(betapart)
library(vioplot)

### North American .shps
US_map<-readOGR(dsn = "/Users/darrocsa/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/code/NAmer_shps/NAmer.shp", layer = "NAmer")
US_map_rangeproj<-spTransform(US_map, CRS("+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"))

### North American mammal ranges
mam_data <- readOGR(dsn = "/Users/darrocsa/Desktop/Projects/Range Size Simulations_w.Geography/TERRESTRIAL_MAMMALS/TERRESTRIAL_MAMMALS.shp", layer = "TERRESTRIAL_MAMMALS")
mam_unique <- unique(mam_data@data$scientific)
# mam_clipped<-crop(mam_data, extent(US_map_clipped))

### load up the IUCN list of N. American mammals (N.American_mammals_lim) and extract a vector of names:
mams <- read.csv("~/Desktop/Projects/Range Size Simulations_w.Geography/N.American_mammals_lim.csv")
mam.sp.names <- as.vector(paste(mams$Genus, mams$Species, sep=" "))

# set up an empty list to put subsetted N. American mammals in:
NAtaxa<-list()
counter=1

for (t in 1:length(mam_unique)) {    
    ts<-mam_unique[t]
    tmp<-mam_data[which(mam_data$scientific == ts) , ]
    name<-as.character(tmp$scientific[1])
    # print(name)   
    if (name %in% mam.sp.names == TRUE){    	
    	NAtaxa[[counter]]<-tmp
    	counter=counter+1    	
    }  
    # print(counter)    
}    

### see how many species we have in there...

all_species<-NAtaxa
l.species<-length(all_species)

# get a vector species names
sp.names<-c()

for (smut in 1:length(NAtaxa)){
	t.smut<-NAtaxa[[smut]]
	nm<-t.smut$scientific[1]
	sp.names<-c(sp.names, as.character(nm))
}

# just in case...
# length(all_species)
# all_species2<-all_species[-328] # gets rid of Ursus americanus, which has a corrupt geometry
# l.species2<-length(all_species2)
# l.species2
# sp.names2<-sp.names[-328] # Again...gets rid of Ursus americanus

# time info
ranch<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/pbdb_data/Rancholabrean_trimmed.csv", row.names=1)
rls<-paste(ranch$lat, ranch$lng, sep="&")
urls<-unique(rls)

# now get into a new table
ranch_locals_prelim<-array(NA, dim=c(length(urls), 2))
colnames(ranch_locals_prelim)<-c("lat","long")
for (s in 1:length(urls)){
	turls<-urls[s]
	cs<-strsplit(turls, "&")
	ranch_locals_prelim[s,1]<-as.numeric(cs[[1]][2])
	ranch_locals_prelim[s,2]<-as.numeric(cs[[1]][1])
}

ranch_locals_prelim<-as.data.frame(ranch_locals_prelim)

# take a quick look at the distribution of localities
ft<-cbind(ranch_locals_prelim$lat, ranch_locals_prelim$long)
lc<-coordinates(ft)
frp<-SpatialPointsDataFrame(lc, ranch_locals_prelim, proj4string=CRS("+proj=longlat +datum=WGS84"))
projection(frp)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	

# and plot
# dev.new(height=8, width=8)
# plot(US_map_rangeproj, col="white", axes=T)
# points(frp, pch=21, col="black", bg="red", cex=0.7)

# lastly, we need to crop these by out N. American .shp polygon
cropped_locals<-gIntersection(US_map_rangeproj, frp)

# plot again
dev.new(height=8, width=8)
plot(US_map_rangeproj, col="white", axes=T)
points(cropped_locals, pch=21, col="black", bg="red", cex=0.7)

# and re-save as a simple dataframe
cropped_locals.df<-as.data.frame(cropped_locals) # 718 unique localities
ranch_coords<-cropped_locals.df
ranch.locals<-nrow(ranch_coords)

# taphonomy table
taph.table<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Probabilities_of_preservation.csv", header=T)

# take a quick look at the distribution of probabilities...
prob.distr<-taph.table[order(taph.table$CorrProb) , ]
dev.new(height=8, width=8)
plot(prob.distr$CorrProb)

# make a probability vector
prob.vec<-seq(0, 1, by=0.01)

# lagerstatten vector
lager.vec<-seq(0.01, 1, by=0.01)

# load body masses
body.mass.table<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Elton_traits1.0.csv")
attach(body.mass.table)

# owl pellet size threshold
pellet.large.thresh<-800 # set max. prey mammal size
pellet.small.thresh<-5 # set min. prey mammal size

# baseline data
baseline<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/baseline_ranges.csv")

#################################################################################################################################################################
#################################################################################################################################################################

### first produce a 1 degree raster for all diversity, so we can do correlations stats after simulating a fossil record

# grid resolution
gridres<-1

# raster list
raster.list<-list()

# loop
for (j in 1:l.species){
		
	c.species<-all_species[[j]]
	projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
	cl.species<-gIntersection(US_map_rangeproj, c.species)
	
	if (is.null(cl.species)) { 			
				
		print(paste(c.species$scientific[1], "IS NULL", sep = "  "))
			
		} else {	
			
		r.species<-spTransform(cl.species, CRS("+proj=cea +lat_ts=30"))	
		r.species.a<-gArea(r.species)
		res<-paste(c.species$scientific[1], r.species.a/10^6, "km2", sep=" ")
		print(res)
		
		# and add to the plot
		# plot(cl.species, col=trans.red, border=trans.red, add=T)
		
		# try some funky raster stuff
		# make a raster
		raz<-raster(ncol=360/gridres, nrow=180/gridres, xmn=-180, xmx=180, ymn=-90, ymx=90)
		raz <-setValues(raz, c(0))
		raz.fix<-rasterize(cl.species, raz, fun='sum', background=NA, mask=FALSE, update=FALSE, updateValue='all', filename="", getCover=FALSE, silent=TRUE)
		
		# put in raster list
		raster.list[j]<-raz.fix
	
	}
	
}

raster.list2 <- raster.list[-which(sapply(raster.list, is.null))]
s <- raster::stack(raster.list2)
class(s)
datasum<- stackApply(s, indices=1, fun = sum)

### now plot
richness.cols<-colorRampPalette(c("white","forest green","yellow","orange"), alpha=TRUE)(400)
richness.cols2<-colorRampPalette(c("white","forest green","yellow","orange"), alpha=TRUE)(20)

dev.new(height=8, width=8)
plot(US_map_rangeproj, axes=T, xlim=c(-160, -40), ylim=c(10,90))
rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col = "white")
plot(US_map_rangeproj, col="white", add=T)
# plot(raz.fix)
plot(datasum, col=richness.cols, add=T, zlim=c(0,90))

#################################################################################################################################################################
#################################################################################################################################################################

# Now we need 'trimmed' datasets, to compare results with once we perform extinction experiments

dim(baseline)
baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
# baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

### remember that this needs to match the extinction levels seen in experiments

# record the species list
trimmed.list<-c(as.character(baseline.trimmed$X))

# grid resolution
gridres<-1

# raster list
raster.list<-list()

# loop
for (j in 1:l.species){
		
	c.species<-all_species[[j]]
	c.species.name<-c.species$scientific[1]
	projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
	cl.species<-gIntersection(US_map_rangeproj, c.species)
	
	if (c.species.name %in% trimmed.list) {
	
		if (is.null(cl.species)) { 			
				
			print(paste(c.species$scientific[1], "IS NULL", sep = "  "))
			
			} else {	
			
			r.species<-spTransform(cl.species, CRS("+proj=cea +lat_ts=30"))	
			r.species.a<-gArea(r.species)
			res<-paste(c.species$scientific[1], r.species.a/10^6, "km2", sep=" ")
			print(res)
		
			# and add to the plot
			# plot(cl.species, col=trans.red, border=trans.red, add=T)
		
			# try some funky raster stuff
			# make a raster
			raz<-raster(ncol=360/gridres, nrow=180/gridres, xmn=-180, xmx=180, ymn=-90, ymx=90)
			raz <-setValues(raz, c(0))
			raz.fix<-rasterize(cl.species, raz, fun='sum', background=NA, mask=FALSE, update=FALSE, updateValue='all', filename="", getCover=FALSE, silent=TRUE)
		
			# put in raster list
			raster.list[j]<-raz.fix
			
		} # if it has a presence
	
	} # if it's in the trimmed list
	
} # for all species

raster.list3 <- raster.list[-which(sapply(raster.list, is.null))]
s3 <- raster::stack(raster.list3)
class(s3)
datasum_trim <- stackApply(s3, indices=1, fun = sum)

#################################################################################################################################################################
#################################################################################################################################################################

### now create some fossil records, re-map diversity, and quantify similarity with actual richness patterns

#################################################################################################################################################################
#################################################################################################################################################################

### 'random'

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results")

# paramaters
iter<-100
sites<-300

### establish 'extinction' level
dim(baseline)
baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
# baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

# record the species list
trimmed.list<-c(as.character(baseline.trimmed$X))

# results array
rascor.array<-array(NA, dim=c(iter, 2))
colnames(rascor.array)<-c("simmed","extrapolated")

# loop
for (it in 1:iter){
	
	print(it) # lets keep track
	
	# simulate fossil record
	fr<-spsample(US_map_rangeproj, sites, "random", iter=100)
	
	# create a pres/abs table
	sp.array<-array(0, dim=c(sites, l.species))
	# dim(sp.array)
	colnames(sp.array)<-c(sp.names)
	
	for (j in 1: l.species){
		
		c.species<-all_species[[j]]
		c.species.name<-c.species$scientific[1]
		name<-as.character(c.species.name)
		
		if (c.species.name %in% trimmed.list) {
		
		projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	
		cl.species<-gIntersection(US_map_rangeproj, c.species)
		
		if (is.null(cl.species)) { 	    
				
			print(paste(c.species$scientific[1], "IS NULL", sep = "  "))
			
		} else {

		exf<-extract(cl.species, fr, buffer=20) # puts a 20 meter buffer around the sampling site
		hits<-exf[ which(exf$poly.ID=="1") , ]
		hit.pts<-as.vector(hits$point.ID)
		sp.array[c(hit.pts) , name]<-1
		
			} # if the species has a presence
		
		} # If its in our trimmed list
	
	} # for all species
	
	# now let's bung this in a matrix with some lat./long. and richness info
	remapping.array<-array(NA, dim=c(sites, 3))
	colnames(remapping.array)<-c("lat", "long", "richness")
	remapping.array[,1]<-as.vector(fr$y)
	remapping.array[,2]<-as.vector(fr$x)
	remapping.array[,3]<-as.vector(rowSums(sp.array))
	
	# save .csv
	# write.csv(remapping.array, "remapping_div_3.csv")
	
	# now do some raster correlations
	sub.ras<-raster(ncol=360/1, nrow=180/1, xmn=-180, xmx=180, ymn=-90, ymx=90)
	s2<-rasterize(fr, sub.ras, field=c(remapping.array[,3]))
	f<-focal(s2, w=matrix(1,3,3), fun=mean, na.rm=TRUE)
	actuals<-values(datasum_trim)
	simulated<-values(s)
	simulated2<-values(f)
	rascor<-cor.test(actuals, simulated, method="kendall")
	rascor2<-cor.test(actuals, simulated2, method="kendall")
		
	# save 'em
	trw<-rascor$estimate
	trw2<-rascor2$estimate	
	rascor.array[it,1]<-trw
	rascor.array[it,2]<-trw2
	
	write.csv(rascor.array, "random_rascor_array_300s_0trim.csv")
	
} # for all iterations

# plot for fun
dev.new(height=8, width=8)
plot(US_map_rangeproj, axes=T, xlim=c(-160, -40), ylim=c(10,90))
rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col = "white")
plot(US_map_rangeproj, col="white", add=T)
plot(f1, col=richness.cols, add=T, zlim=c(0,90))

# and mess about with the size of the smoothing window
f2<-focal(s, w=matrix(1,5,5), fun=mean, na.rm=TRUE)
simulated3<-values(f1)
rascor3<-cor.test(actuals, simulated3, method="kendall")

#################################################################################################################################################################
#################################################################################################################################################################

### 'localities'

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results")

# paramaters
iter<-100
sites<-300

### establish 'extinction' level
dim(baseline)
baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
# baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

# record the species list
trimmed.list<-c(as.character(baseline.trimmed$X))

# results array
rascor.array<-array(NA, dim=c(iter, 2))
colnames(rascor.array)<-c("simmed","extrapolated")

# loop
for (it in 1:iter){
	
	print(it) # keep track
	
	# simulate fossil record
	locs_1<-sample(ranch.locals, sites, replace=FALSE)
	locs_2<-ranch_coords[locs_1 , ]
	locs_3<-as.data.frame(locs_2)
	fr<-SpatialPointsDataFrame(locs_2, locs_3, proj4string=CRS("+proj=longlat +datum=WGS84"))
	projection(fr)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"
	
	# create a pres/abs table
	sp.array<-array(0, dim=c(sites, l.species))
	# dim(sp.array)
	colnames(sp.array)<-c(sp.names)
	
	for (j in 1: l.species){
		
		c.species<-all_species[[j]]
		c.species.name<-c.species$scientific[1]
		name<-as.character(c.species.name)
		
		if (c.species.name %in% trimmed.list) {
		
		projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	
		cl.species<-gIntersection(US_map_rangeproj, c.species)
		
		if (is.null(cl.species)) { 	    
				
			print(paste(c.species$scientific[1], "IS NULL", sep = "  "))
			
		} else {

		exf<-extract(cl.species, fr, buffer=20) # puts a 20 meter buffer around the sampling site
		hits<-exf[ which(exf$poly.ID=="1") , ]
		hit.pts<-as.vector(hits$point.ID)
		sp.array[c(hit.pts) , name]<-1
		
			} # if the species has a presence
		
		} # If its in our trimmed list
	
	} # for all species
	
	# now let's bung this in a matrix with some lat./long. and richness info
	remapping.array<-array(NA, dim=c(sites, 3))
	colnames(remapping.array)<-c("lat", "long", "richness")
	remapping.array[,1]<-as.vector(fr$y)
	remapping.array[,2]<-as.vector(fr$x)
	remapping.array[,3]<-as.vector(rowSums(sp.array))
	
	# save .csv
	# write.csv(remapping.array, "remapping_div_3.csv")
	
	# perform raster correlations
	sub.ras<-raster(ncol=360/1, nrow=180/1, xmn=-180, xmx=180, ymn=-90, ymx=90)
	s3<-rasterize(fr, sub.ras, field=c(remapping.array[,3]))
	f<-focal(s3, w=matrix(1,3,3), fun=mean, na.rm=TRUE)
	actuals<-values(datasum_trim)
	simulated<-values(s)
	simulated2<-values(f)
	rascor<-cor.test(actuals, simulated, method="kendall")
	rascor2<-cor.test(actuals, simulated2, method="kendall")
		
	# save values
	trw<-rascor$estimate
	trw2<-rascor2$estimate	
	rascor.array[it,1]<-trw
	rascor.array[it,2]<-trw2
	
	write.csv(rascor.array, "localities_rascor_array_300s_0trim.csv")
	
} # for all iterations

# plot for fun
dev.new(height=8, width=8)
plot(US_map_rangeproj, axes=T, xlim=c(-160, -40), ylim=c(10,90))
rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col = "white")
plot(US_map_rangeproj, col="white", add=T)
plot(f, col=richness.cols, add=T, zlim=c(0,90))

# and mess about with the size of the smoothing window
f1<-focal(s, w=matrix(1,5,5), fun=mean, na.rm=TRUE)
simulated3<-values(f1)
rascor3<-cor.test(actuals, simulated3, method="kendall")

#################################################################################################################################################################
#################################################################################################################################################################

### 'taphonomy'

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results")

# paramaters
iter<-100
sites<-300

### establish 'extinction' level
dim(baseline)
baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
# baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

# record the species list
trimmed.list<-c(as.character(baseline.trimmed$X))

# results array
rascor.array<-array(NA, dim=c(iter, 2))
colnames(rascor.array)<-c("simmed","extrapolated")

# loop
for (it in 1:iter){
	
	print(it) # lets keep track
	
	# simulate fossil record
	locs_1<-sample(ranch.locals, sites, replace=FALSE)
	locs_2<-ranch_coords[locs_1 , ]
	locs_3<-as.data.frame(locs_2)
	fr<-SpatialPointsDataFrame(locs_2, locs_3, proj4string=CRS("+proj=longlat +datum=WGS84"))
	projection(fr)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"
	
	# create a pres/abs table
	sp.array<-array(0, dim=c(sites, l.species))
	# dim(sp.array)
	colnames(sp.array)<-c(sp.names)
	
	for (j in 1: l.species){
		
		c.species<-all_species[[j]]
		c.species.name<-c.species$scientific[1]
		name<-as.character(c.species.name)
		
		if (c.species.name %in% trimmed.list) {
		
		projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	
		cl.species<-gIntersection(US_map_rangeproj, c.species)
		
		if (is.null(cl.species)) { 	    
				
			print(paste(c.species$scientific[1], "IS NULL", sep = "  "))
			
		} else {
			
		### now the taphonomy part
		this.species<-taph.table[ which(taph.table$X == name) , ]
		this.species.prob<-this.species[,3]

		exf<-extract(cl.species, fr, buffer=20) # puts a 20 meter buffer around the sampling site
		hits<-exf[ which(exf$poly.ID=="1") , ]
		hit.pts<-as.vector(hits$point.ID)

		# now we go through the hit points, and roll the dice for each one
		for (hp in 1:length(hit.pts)){
			
			this.hp<-hit.pts[hp]
			prob<-sample(prob.vec, 1)
			
			# let's take a look at this...should ideally get a mixture of TRUE and FALSE
			print(paste(name, prob, this.species.prob, prob <= this.species.prob, sep="  "))
			
				# now generate the 'if' clause
				if (prob <= this.species.prob) {

					sp.array[this.hp , name]<-1
			
					} # only if the species is 'found'
		
				} # for all hit points

			} # if the species has a presence
		
		} # If its in our trimmed list
	
	} # for all species
	
	# now let's bung this in a matrix with some lat./long. and richness info
	remapping.array<-array(NA, dim=c(sites, 3))
	colnames(remapping.array)<-c("lat", "long", "richness")
	remapping.array[,1]<-as.vector(fr$y)
	remapping.array[,2]<-as.vector(fr$x)
	remapping.array[,3]<-as.vector(rowSums(sp.array))
	
	# save .csv
	# write.csv(remapping.array, "remapping_div_3.csv")
	
	# now do some funky rastre correlations
	sub.ras<-raster(ncol=360/1, nrow=180/1, xmn=-180, xmx=180, ymn=-90, ymx=90)
	s4<-rasterize(fr, sub.ras, field=c(remapping.array[,3]))
	f<-focal(s4, w=matrix(1,3,3), fun=mean, na.rm=TRUE)
	actuals<-values(datasum_trim) ### remember to change this as you switch between all and subbed datasets!
	simulated<-values(s)
	simulated2<-values(f)
	rascor<-cor.test(actuals, simulated, method="kendall")
	rascor2<-cor.test(actuals, simulated2, method="kendall")
		
	# save 'em
	trw<-rascor$estimate
	trw2<-rascor2$estimate	
	rascor.array[it,1]<-trw
	rascor.array[it,2]<-trw2
	
	write.csv(rascor.array, "taphonomy_rascor_array_300s_0trim.csv")
	
} # for all iterations

# plot for fun
dev.new(height=8, width=8)
plot(US_map_rangeproj, axes=T, xlim=c(-160, -40), ylim=c(10,90))
rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col = "white")
plot(US_map_rangeproj, col="white", add=T)
plot(f, col=richness.cols, add=T, zlim=c(0,90))

# and mess about with the size of the smoothing window
f1<-focal(s4, w=matrix(1,5,5), fun=mean, na.rm=TRUE)
simulated3<-values(f1)
rascor3<-cor.test(actuals, simulated3, method="kendall")

#################################################################################################################################################################
#################################################################################################################################################################

### 'lagerstatten'

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results")

# paramaters
iter<-100
sites<-300

### establish 'extinction' level
dim(baseline)
baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
# baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

# record the species list
trimmed.list<-c(as.character(baseline.trimmed$X))

# results array
rascor.array<-array(NA, dim=c(iter, 3))
colnames(rascor.array)<-c("simmed","extrapolated","lagerstatten")

# loop
for (it in 1:iter){
	
	print(it) # keep track
	
	# simulate fossil record
	locs_1<-sample(ranch.locals, sites, replace=FALSE)
	locs_2<-ranch_coords[locs_1 , ]
	locs_3<-as.data.frame(locs_2)
	fr<-SpatialPointsDataFrame(locs_2, locs_3, proj4string=CRS("+proj=longlat +datum=WGS84"))
	projection(fr)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	
	
	# create a pres/abs table
	sp.array<-array(0, dim=c(sites, l.species))
	# dim(sp.array)
	colnames(sp.array)<-c(sp.names)
	
	# start a lagetsatten counter
	l.count<-0

	#################################################################################
	
	# do the lagerstatten function immediately	
	for (pot.lagerstatten in 1:length(fr)){
		
		this.pot.site<-locs_3[pot.lagerstatten , ]
		
		# roll the lagerstatten dice
		lager.prob<-sample(lager.vec, 1)
		
		if (lager.prob == 1.00){
			
			print("LAGERSTATTEN!!!")
			l.count<-l.count+1
			
			for (ll in 1:l.species){
		
			l.c.species<-all_species[[ll]]
			l.c.species.name<-l.c.species$scientific[1]
			l.name<-as.character(l.c.species.name)
			projection(l.c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
			l.cl.species<-gIntersection(US_map_rangeproj, l.c.species)
			
			if (is.null(l.cl.species)) { 	    
				
				print(paste(c.species$scientific[1], "IS NULL", sep = "  "))
			
			} else {
		
			if (l.c.species.name %in% trimmed.list) {
				
				lag<-as.data.frame(this.pot.site)
				lagerstatten<-SpatialPointsDataFrame(this.pot.site, lag, proj4string=CRS("+proj=longlat +datum=WGS84"))
				projection(lagerstatten)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"
				exf<-extract(l.cl.species, lagerstatten, buffer=20) # puts a 20 meter buffer around the sampling site
				exf[is.na(exf)] <- 0 # we need to find a way to find out if the locality 'hits' the species in question
				
				if (exf$poly.ID >= 1){
					
						sp.array[pot.lagerstatten, l.name]<-1 # get them in there
					
						}

					} # if it's in the trimmed species list
				
				} # if it has a presence
			
			} # for all species in the list
			
		} # if the site is a lagerstatten
		
	} # for all fossil localities in this iteration
	
	# rowSums(sp.array)
	# colSums(sp.array)
	
	#################################################################################
	
	for (j in 1: l.species){
		
		c.species<-all_species[[j]]
		c.species.name<-c.species$scientific[1]
		name<-as.character(c.species.name)
		
		if (c.species.name %in% trimmed.list) {
		
		projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	
		cl.species<-gIntersection(US_map_rangeproj, c.species)
		
		if (is.null(cl.species)) { 	    
				
			print(paste(c.species$scientific[1], "IS NULL", sep = "  "))
			
		} else {
			
		### now the taphonomy part
		this.species<-taph.table[ which(taph.table$X == name) , ]
		this.species.prob<-this.species[,3]

		exf<-extract(cl.species, fr, buffer=20) # puts a 20 meter buffer around the sampling site
		hits<-exf[ which(exf$poly.ID=="1") , ]
		hit.pts<-as.vector(hits$point.ID)

		# now we go through the hit points, and roll the dice for each one
		for (hp in 1:length(hit.pts)){
			
			this.hp<-hit.pts[hp]
			prob<-sample(prob.vec, 1)
			
			# let's take a look at this...should ideally get a mixture of TRUE and FALSE
			print(paste(name, prob, this.species.prob, prob <= this.species.prob, sep="  "))
			
				# now generate the 'if' clause
				if (prob <= this.species.prob) {

					sp.array[this.hp , name]<-1
			
					} # only if the species is 'found'
		
				} # for all hit points

			} # if the species has a presence
		
		} # If its in our trimmed list
	
	} # for all species
	
	# now put in a matrix with some lat./long. and richness info
	remapping.array<-array(NA, dim=c(sites, 3))
	colnames(remapping.array)<-c("lat", "long", "richness")
	remapping.array[,1]<-as.vector(fr$y)
	remapping.array[,2]<-as.vector(fr$x)
	remapping.array[,3]<-as.vector(rowSums(sp.array))
	
	# save .csv
	# write.csv(remapping.array, "remapping_div_3.csv")
	
	# now do raster correlations
	sub.ras<-raster(ncol=360/1, nrow=180/1, xmn=-180, xmx=180, ymn=-90, ymx=90)
	s5<-rasterize(fr, sub.ras, field=c(remapping.array[,3]))
	f<-focal(s5, w=matrix(1,3,3), fun=mean, na.rm=TRUE)
	actuals<-values(datasum) ### remember to change this as you switch between all and subbed datasets!
	simulated<-values(s5)
	simulated2<-values(f)
	rascor<-cor.test(actuals, simulated, method="kendall")
	rascor2<-cor.test(actuals, simulated2, method="kendall")
		
	# save them
	trw<-rascor$estimate
	trw2<-rascor2$estimate	
	rascor.array[it,1]<-trw
	rascor.array[it,2]<-trw2
	rascor.array[it,3]<-l.count
	
	write.csv(rascor.array, "lagerstatten_rascor_array_300s_0trim.csv")
	
} # for all iterations

# plot for fun
dev.new(height=8, width=8)
plot(US_map_rangeproj, axes=T, xlim=c(-160, -40), ylim=c(10,90))
rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col = "white")
plot(US_map_rangeproj, col="white", add=T)
plot(f, col=richness.cols, add=T, zlim=c(0,90))

# and mess about with the size of the smoothing window
f1<-focal(s4, w=matrix(1,5,5), fun=mean, na.rm=TRUE)
simulated3<-values(f1)
rascor3<-cor.test(actuals, simulated3, method="kendall")

#################################################################################################################################################################
#################################################################################################################################################################

### 'castings'

# set working directory
setwd("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results")

# paramaters
iter<-100
sites<-300

### establish 'extinction' level
dim(baseline)
baseline.trimmed<-baseline[1:nrow(baseline),] # 374 species
# baseline.trimmed<-baseline[94:nrow(baseline),]
# baseline.trimmed<-baseline[187:nrow(baseline),]
# baseline.trimmed<-baseline[280:nrow(baseline),]
dim(baseline.trimmed) # check

# record the species list
trimmed.list<-c(as.character(baseline.trimmed$X))

# results array
rascor.array<-array(NA, dim=c(iter, 2))
colnames(rascor.array)<-c("simmed","extrapolated")

# loop
for (it in 1:iter){
	
	print(it) # keep track
	
	# simulate fossil record
	locs_1<-sample(ranch.locals, sites, replace=FALSE)
	locs_2<-ranch_coords[locs_1 , ]
	locs_3<-as.data.frame(locs_2)
	fr<-SpatialPointsDataFrame(locs_2, locs_3, proj4string=CRS("+proj=longlat +datum=WGS84"))
	projection(fr)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	
	
	# create a pres/abs table
	sp.array<-array(0, dim=c(sites, l.species))
	# dim(sp.array)
	colnames(sp.array)<-c(sp.names)

	#################################################################################
	
	# lagerstatten	
	for (pot.lagerstatten in 1:length(fr)){
		
		this.pot.site<-locs_3[pot.lagerstatten , ]
		
		# roll the lagerstatten dice
		lager.prob<-sample(lager.vec, 1)
		
		if (lager.prob == 1.00){
			
			print("LAGERSTATTEN!!!")
			
			for (ll in 1:l.species){
		
			l.c.species<-all_species[[ll]]
			l.c.species.name<-l.c.species$scientific[1]
			l.name<-as.character(l.c.species.name)
			projection(l.c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	 # get the range in the right projection
			l.cl.species<-gIntersection(US_map_rangeproj, l.c.species)
			
			if (is.null(l.cl.species)) { 	    
				
				print(paste(c.species$scientific[1], "IS NULL", sep = "  "))
			
			} else {
		
			if (l.c.species.name %in% trimmed.list) {
				
				lag<-as.data.frame(this.pot.site)
				lagerstatten<-SpatialPointsDataFrame(this.pot.site, lag, proj4string=CRS("+proj=longlat +datum=WGS84"))
				projection(lagerstatten)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"
				exf<-extract(l.cl.species, lagerstatten, buffer=20) # puts a 20 meter buffer around the sampling site
				exf[is.na(exf)] <- 0 # we need to find a way to find out if the locality 'hits' the species in question
				
				if (exf$poly.ID >= 1){
					
						sp.array[pot.lagerstatten, l.name]<-1 # get them in there
					
						}

					} # if it's in the trimmed species list
				
				} # if it has a presence
				
			} # for all species in the list
			
		} # if the site is a lagerstatten
		
	} # for all fossil localities in this iteration
	
	# rowSums(sp.array)
	# colSums(sp.array)
	
	#################################################################################
	
	for (j in 1: l.species){
		
		c.species<-all_species[[j]]
		c.species.name<-c.species$scientific[1]
		name<-as.character(c.species.name)
		
		if (c.species.name %in% trimmed.list) {
		
		projection(c.species)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	
		cl.species<-gIntersection(US_map_rangeproj, c.species)
		
		if (is.null(cl.species)) { 	    
				
			print(paste(c.species$scientific[1], "IS NULL", sep = "  "))
			
		} else {
			
		### now the taphonomy part
		this.species<-taph.table[ which(taph.table$X == name) , ]
		this.species.prob<-this.species[,3]

		exf<-extract(cl.species, fr, buffer=20) # puts a 20 meter buffer around the sampling site
		hits<-exf[ which(exf$poly.ID=="1") , ]
		hit.pts<-as.vector(hits$point.ID)

		# now we go through the hit points, and roll the dice for each one
		for (hp in 1:length(hit.pts)){
			
			this.hp<-hit.pts[hp]
			prob<-sample(prob.vec, 1)
			
			# let's take a look at this...should ideally get a mixture of TRUE and FALSE
			print(paste(name, prob, this.species.prob, prob <= this.species.prob, sep="  "))
			
				# now generate the 'if' clause
				if (prob <= this.species.prob) {

					sp.array[this.hp , name]<-1
			
					} # only if the species is 'found'
		
				} # for all hit points
				
			# now we put in the owl pellet stuff, much in the same fashion
			for (hhp in 1:length(hit.pts)){
			
			this.hhp<-hit.pts[hhp]
			this.body.mass.data<-body.mass.table[ which(body.mass.table$Species == as.character(c.species.name)) , ]
			this.body.mass<-as.numeric(this.body.mass.data[26]) # make sure body mass is in the 26th column
			
			# now generate the 'if' clauses
			if (this.body.mass <= pellet.large.thresh & this.body.mass >= pellet.small.thresh) {

				sp.array[this.hhp , name]<-1
			
					} # only if the species is small/large enough to be owl bait
		
				} # for all hit points

			} # if the species has a presence
		
		} # If its in our trimmed list
	
	} # for all species
	
	# now put this in a matrix with some lat./long. and richness info
	remapping.array<-array(NA, dim=c(sites, 3))
	colnames(remapping.array)<-c("lat", "long", "richness")
	remapping.array[,1]<-as.vector(fr$y)
	remapping.array[,2]<-as.vector(fr$x)
	remapping.array[,3]<-as.vector(rowSums(sp.array))
	
	# save .csv
	# write.csv(remapping.array, "remapping_div_3.csv")
	
	# now perform raster correlations
	sub.ras<-raster(ncol=360/1, nrow=180/1, xmn=-180, xmx=180, ymn=-90, ymx=90)
	s6<-rasterize(fr, sub.ras, field=c(remapping.array[,3]))
	f<-focal(s6, w=matrix(1,3,3), fun=mean, na.rm=TRUE)
	actuals<-values(datasum) ### remember to change this as you switch between all and subbed datasets!
	simulated<-values(s6)
	simulated2<-values(f)
	rascor<-cor.test(actuals, simulated, method="kendall")
	rascor2<-cor.test(actuals, simulated2, method="kendall")
		
	# save them
	trw<-rascor$estimate
	trw2<-rascor2$estimate	
	rascor.array[it,1]<-trw
	rascor.array[it,2]<-trw2
	
	write.csv(rascor.array, "castings_rascor_array_300s_0trim.csv")
	
} # for all iterations

# plot for fun
dev.new(height=8, width=8)
plot(US_map_rangeproj, axes=T, xlim=c(-160, -40), ylim=c(10,90))
rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col = "white")
plot(US_map_rangeproj, col="white", add=T)
plot(f, col=richness.cols, add=T, zlim=c(0,90))

# and mess about with the size of the smoothing window
f1<-focal(s6, w=matrix(1,5,5), fun=mean, na.rm=TRUE)
simulated3<-values(f1)
rascor3<-cor.test(actuals, simulated3, method="kendall")

#################################################################################################################################################################

### plotting

random_0<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/random_rascor_array_300s_0trim.csv")
random_25<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/random_rascor_array_300s_25trim.csv")
random_50<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/random_rascor_array_300s_50trim.csv")
random_75<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/random_rascor_array_300s_75trim.csv")

locals_0<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/localities_rascor_array_300s_0trim.csv")
locals_25<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/localities_rascor_array_300s_25trim.csv")
locals_50<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/localities_rascor_array_300s_50trim.csv")
locals_75<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/localities_rascor_array_300s_75trim.csv")

taph_0<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/taphonomy_rascor_array_300s_0trim.csv")
taph_25<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/taphonomy_rascor_array_300s_25trim.csv")
taph_50<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/taphonomy_rascor_array_300s_50trim.csv")
taph_75<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/taphonomy_rascor_array_300s_75trim.csv")

lager_0<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/lagerstatten_rascor_array_300s_0trim.csv")
lager_25<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/lagerstatten_rascor_array_300s_25trim.csv")
lager_50<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/lagerstatten_rascor_array_300s_50trim.csv")
lager_75<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/lagerstatten_rascor_array_300s_75trim.csv")

castings_0<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/castings_rascor_array_300s_0trim.csv")
castings_25<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/castings_rascor_array_300s_25trim.csv")
castings_50<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/castings_rascor_array_300s_50trim.csv")
castings_75<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/remapping/castings_rascor_array_300s_75trim.csv")

# first set of plots...'simmed'

random_v1<-list(random_0[,2], random_25[,2], random_50[,2], random_75[,2])
locals_v1<-list(locals_0[,2], locals_25[,2], locals_50[,2], locals_75[,2])
taph_v1<-list(taph_0[,2], taph_25[,2], taph_50[,2], taph_75[,2])
lager_v1<-list(lager_0[,2], lager_25[,2], lager_50[,2], lager_75[,2])
castings_v1<-list(castings_0[,2], castings_25[,2], castings_50[,2], castings_75[,2])

# and the second...'extrapolated'

random_v2<-list(random_0[,3], random_25[,3], random_50[,3], random_75[,3])
locals_v2<-list(locals_0[,3], locals_25[,3], locals_50[,3], locals_75[,3])
taph_v2<-list(taph_0[,3], taph_25[,3], taph_50[,3], taph_75[,3])
lager_v2<-list(lager_0[,3], lager_25[,3], lager_50[,3], lager_75[,3])
castings_v2<-list(castings_0[,3], castings_25[,3], castings_50[,3], castings_75[,3])


dev.new(height=14, width=6)
par(mfcol=c(5,2))
par(mar=c(4,4,2,2))

vioplot(as.numeric(random_0[,2]), as.numeric(random_25[,2]), as.numeric(random_50[,2]), as.numeric(random_75[,2]), col="pink", ylim=c(-0.2,1), names=c("all","25","50","75"))
abline(h=0, lty=3)
vioplot(as.numeric(locals_0[,2]), as.numeric(locals_25[,2]), as.numeric(locals_50[,2]), as.numeric(locals_75[,2]), col="pink", ylim=c(-0.2,1), names=c("all","25","50","75"))
abline(h=0, lty=3)
vioplot(as.numeric(taph_0[,2]), as.numeric(taph_25[,2]), as.numeric(taph_50[,2]), as.numeric(taph_75[,2]), col="pink", ylim=c(-0.2,1), names=c("all","25","50","75"))
abline(h=0, lty=3)
vioplot(as.numeric(lager_0[,2]), as.numeric(lager_25[,2]), as.numeric(lager_50[,2]), as.numeric(lager_75[,2]), col="pink", ylim=c(-0.2,1), names=c("all","25","50","75"))
abline(h=0, lty=3)
vioplot(as.numeric(castings_0[,2]), as.numeric(castings_25[,2]), as.numeric(castings_50[,2]), as.numeric(castings_75[,2]), col="pink", ylim=c(-0.2,1), names=c("all","25","50","75"))
abline(h=0, lty=3)

vioplot(as.numeric(random_0[,3]), as.numeric(random_25[,3]), as.numeric(random_50[,3]), as.numeric(random_75[,3]), col="pink", ylim=c(-0.2,1), names=c("all","25","50","75"))
abline(h=0, lty=3)
vioplot(as.numeric(locals_0[,3]), as.numeric(locals_25[,3]), as.numeric(locals_50[,3]), as.numeric(locals_75[,3]), col="pink", ylim=c(-0.2,1), names=c("all","25","50","75"))
abline(h=0, lty=3)
vioplot(as.numeric(taph_0[,3]), as.numeric(taph_25[,3]), as.numeric(taph_50[,3]), as.numeric(taph_75[,3]), col="pink", ylim=c(-0.2,1), names=c("all","25","50","75"))
abline(h=0, lty=3)
vioplot(as.numeric(lager_0[,3]), as.numeric(lager_25[,3]), as.numeric(lager_50[,3]), as.numeric(lager_75[,3]), col="pink", ylim=c(-0.2,1), names=c("all","25","50","75"))
abline(h=0, lty=3)
vioplot(as.numeric(castings_0[,3]), as.numeric(castings_25[,3]), as.numeric(castings_50[,3]), as.numeric(castings_75[,3]), col="pink", ylim=c(-0.2,1), names=c("all","25","50","75"))
abline(h=0, lty=3)

#################################################################################################################################################################
