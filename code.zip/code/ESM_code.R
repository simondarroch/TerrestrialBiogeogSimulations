################################################################################################################

### 'clean' code mapping diversity in North American mammals under ext. scenarios, and measuring beta diversity

###
rm(list=ls())

### packages
library(maptools)
library(sp)
library(PBSmapping)
library(rgeos)
library(spdep)
library(rgdal)
library(splancs)
library(pastecs)
library(plotrix)
library(raster)
library(geosphere)
library(betapart)

### North American .shps
US_map<-readOGR(dsn = "/Users/darrocsa/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/code/NAmer_shps/NAmer.shp", layer = "NAmer")
US_map_rangeproj<-spTransform(US_map, CRS("+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"))

### North American mammal ranges
mam_data <- readOGR(dsn = "/Users/darrocsa/Desktop/Projects/Range Size Simulations_w.Geography/TERRESTRIAL_MAMMALS/TERRESTRIAL_MAMMALS.shp", layer = "TERRESTRIAL_MAMMALS")
mam_unique <- unique(mam_data@data$scientific)
# mam_clipped<-crop(mam_data, extent(US_map_clipped))

### load up the IUCN list of N. American mammals (N.American_mammals_lim) and extract a vector of names:
mams <- read.csv("~/Desktop/Projects/Range Size Simulations_w.Geography/N.American_mammals_lim.csv")
mam.sp.names <- as.vector(paste(mams$Genus, mams$Species, sep=" "))

# set up an empty list to put subsetted N. American mammals in:
NAtaxa<-list()
counter=1

for (t in 1:length(mam_unique)) {    
    ts<-mam_unique[t]
    tmp<-mam_data[which(mam_data$scientific == ts) , ]
    name<-as.character(tmp$scientific[1])
    # print(name)   
    if (name %in% mam.sp.names == TRUE){    	
    	NAtaxa[[counter]]<-tmp
    	counter=counter+1    	
    }  
    # print(counter)    
}    

### see how many species we have in there...

all_species<-NAtaxa
l.species<-length(all_species)

# get a vector species names
sp.names<-c()

for (smut in 1:length(NAtaxa)){
	t.smut<-NAtaxa[[smut]]
	nm<-t.smut$scientific[1]
	sp.names<-c(sp.names, as.character(nm))
}

# just in case...
# length(all_species)
# all_species2<-all_species[-328] # gets rid of Ursus americanus, which has a corrupt geometry
# l.species2<-length(all_species2)
# l.species2
# sp.names2<-sp.names[-328] # Again...gets rid of Ursus americanus

# time info
ranch<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/pbdb_data/Rancholabrean_trimmed.csv", row.names=1)
rls<-paste(ranch$lat, ranch$lng, sep="&")
urls<-unique(rls)

# now get into a new table
ranch_locals_prelim<-array(NA, dim=c(length(urls), 2))
colnames(ranch_locals_prelim)<-c("lat","long")
for (s in 1:length(urls)){
	turls<-urls[s]
	cs<-strsplit(turls, "&")
	ranch_locals_prelim[s,1]<-as.numeric(cs[[1]][2])
	ranch_locals_prelim[s,2]<-as.numeric(cs[[1]][1])
}

ranch_locals_prelim<-as.data.frame(ranch_locals_prelim)

# take a quick look at the distribution of localities
ft<-cbind(ranch_locals_prelim$lat, ranch_locals_prelim$long)
lc<-coordinates(ft)
frp<-SpatialPointsDataFrame(lc, ranch_locals_prelim, proj4string=CRS("+proj=longlat +datum=WGS84"))
projection(frp)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	

# and plot
# dev.new(height=8, width=8)
# plot(US_map_rangeproj, col="white", axes=T)
# points(frp, pch=21, col="red", bg="red", cex=0.7)
# points(fr, pch=21, col="blue", bg="blue", cex=0.7)

# lastly, we need to crop these by out N. American .shp polygon
cropped_locals<-gIntersection(US_map_rangeproj, frp)

# and re-save as a simple dataframe
cropped_locals.df<-as.data.frame(cropped_locals) # 718 unique localities
ranch_coords<-cropped_locals.df
lc<-coordinates(ranch_coords)
frp<-SpatialPointsDataFrame(lc, ranch_coords, proj4string=CRS("+proj=longlat +datum=WGS84"))
projection(frp)<-"+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"	
ranch.locals<-nrow(ranch_coords)

# and re-plot
dev.new(height=8, width=8)
plot(US_map_rangeproj, col="white", axes=T)
points(frp, pch=21, col="red", bg="red", cex=0.7)

# taphonomy table
taph.table<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Probabilities_of_preservation.csv", header=T)

# take a quick look at the distribution of probabilities...
prob.distr<-taph.table[order(taph.table$CorrProb) , ]
plot(prob.distr$CorrProb)

# make a probability vector
prob.vec<-seq(0, 1, by=0.01)

# lagerstatten vector
lager.vec<-seq(0.01, 1, by=0.01)

# load body masses
body.mass.table<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Elton_traits1.0.csv")
attach(body.mass.table)

# owl pellet size threshold
pellet.large.thresh<-800 # set max. prey mammal size
pellet.small.thresh<-5 # set min. prey mammal size

# all species info
baseline<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/baseline_res/allinfo.csv")

################################################################################################################

### ESM 1 - produce a frequency histogram illustrating the distribution of range sizes

dev.new(height=7, width=8)
esm1<-hist(baseline$range_km2, col="light blue", breaks=10, main="range size frequency", xlab="range size (km2)")

################################################################################################################

### ESM 2 - plot the distribution of preservation probabilities

prob.distr<-taph.table[order(taph.table$CorrProb) , ]

dev.new(height=6, width=12)
par(mfrow=c(1,2))
plot(prob.distr$CorrProb, pch=21, col="black", bg="orange", ylab="probability of preservation", xlab="terrestrial mammals", main="probability of preservation")
hist(prob.distr$CorrProb, col="orange", breaks=100, xlab="probability of preservation", main="probability frequency")

################################################################################################################

### ESM 3 - Gamma diversity

# 'random'
random.0.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_0trimmed_3sites.csv")
random.25.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_25trimmed_3sites.csv")
random.50.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_50trimmed_3sites.csv")
random.75.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_75trimmed_3sites.csv")
random.0.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_0trimmed_30sites.csv")
random.25.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_25trimmed_30sites.csv")
random.50.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_50trimmed_30sites.csv")
random.75.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_75trimmed_30sites.csv")
random.0.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_0trimmed_300sites.csv")
random.25.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_25trimmed_300sites.csv")
random.50.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_50trimmed_300sites.csv")
random.75.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/random_75trimmed_300sites.csv")

### 'localities'
localities.0.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_0trimmed_3sites.csv")
localities.25.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_25trimmed_3sites.csv")
localities.50.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_50trimmed_3sites.csv")
localities.75.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_75trimmed_3sites.csv")
localities.0.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_0trimmed_30sites.csv")
localities.25.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_25trimmed_30sites.csv")
localities.50.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_50trimmed_30sites.csv")
localities.75.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_75trimmed_30sites.csv")
localities.0.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_0trimmed_300sites.csv")
localities.25.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_25trimmed_300sites.csv")
localities.50.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_50trimmed_300sites.csv")
localities.75.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/localities_75trimmed_300sites.csv")

### 'taphonomy'
taphonomy.0.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_0trimmed_3sites.csv")
taphonomy.25.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_25trimmed_3sites.csv")
taphonomy.50.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_50trimmed_3sites.csv")
taphonomy.75.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_75trimmed_3sites.csv")
taphonomy.0.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_0trimmed_30sites.csv")
taphonomy.25.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_25trimmed_30sites.csv")
taphonomy.50.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_50trimmed_30sites.csv")
taphonomy.75.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_75trimmed_30sites.csv")
taphonomy.0.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_0trimmed_300sites.csv")
taphonomy.25.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_25trimmed_300sites.csv")
taphonomy.50.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_50trimmed_300sites.csv")
taphonomy.75.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/taphonomy_75trimmed_300sites.csv")

### 'lagerstatten'
lagerstatten.0.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_0trimmed_3sites.csv")
lagerstatten.25.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_25trimmed_3sites.csv")
lagerstatten.50.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_50trimmed_3sites.csv")
lagerstatten.75.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_75trimmed_3sites.csv")
lagerstatten.0.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_0trimmed_30sites.csv")
lagerstatten.25.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_25trimmed_30sites.csv")
lagerstatten.50.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_50trimmed_30sites.csv")
lagerstatten.75.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_75trimmed_30sites.csv")
lagerstatten.0.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_0trimmed_300sites.csv")
lagerstatten.25.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_25trimmed_300sites.csv")
lagerstatten.50.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_50trimmed_300sites.csv")
lagerstatten.75.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/lagerstatten_75trimmed_300sites.csv")

### 'castings'
castings.0.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_0trimmed_3sites.csv")
castings.25.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_25trimmed_3sites.csv")
castings.50.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_50trimmed_3sites.csv")
castings.75.3sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_75trimmed_3sites.csv")
castings.0.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_0trimmed_30sites.csv")
castings.25.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_25trimmed_30sites.csv")
castings.50.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_50trimmed_30sites.csv")
castings.75.30sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_75trimmed_30sites.csv")
castings.0.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_0trimmed_300sites.csv")
castings.25.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_25trimmed_300sites.csv")
castings.50.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_50trimmed_300sites.csv")
castings.75.300sites<-read.csv("~/Desktop/Projects/Range Size Simulations_Beta/Proc B_resubmission/results/beta/castings_75trimmed_300sites.csv")

dev.new(height=16, width=10)
par(mar=c(2,4,2,2))
par(mfrow=c(6,3))

# true diversities
gamma<-c(374,281,188,95)

# top lines of plots
boxplot(c(random.0.3sites[,2]), random.25.3sites[,2], random.50.3sites[,2], random.75.3sites[,2], ylim=c(0,380), type="n", border="white", notch=T, main="3sites_allAreas", ylab="Gamma", names=c("0","25","50","75"))
points(gamma, pch=21, col="black", bg="red", type="b", cex=2)
boxplot(c(random.0.3sites[,2]), random.25.3sites[,2], random.50.3sites[,2], random.75.3sites[,2], ylim=c(0,380), type="n", border="white", notch=T, main="3sites_allAreas", ylab="Gamma", names=c("0","25","50","75"))
points(gamma, pch=21, col="black", bg="red", type="b", cex=2)
boxplot(c(random.0.3sites[,2]), random.25.3sites[,2], random.50.3sites[,2], random.75.3sites[,2], ylim=c(0,380), type="n", border="white", notch=T, main="3sites_allAreas", ylab="Gamma", names=c("0","25","50","75"))
points(gamma, pch=21, col="black", bg="red", type="b", cex=2)

# 'random'
boxplot(c(random.0.3sites[,3]), random.25.3sites[,3], random.50.3sites[,3], random.75.3sites[,3], col="orange", notch=T, main="3sites_random", ylab="Gamma", names=c("All","25","50","75"), boxwex=0.5)
boxplot(c(random.0.30sites[,3]), random.25.30sites[,3], random.50.30sites[,3], random.75.30sites[,3], col="orange", notch=T, main="30sites_random", ylab="Gamma", names=c("0","25","50","75"), boxwex=0.5)
boxplot(c(random.0.300sites[,3]), random.25.300sites[,3], random.50.300sites[,3], random.75.300sites[,3], col="orange", notch=T, main="300sites_random", ylab="Gamma", names=c("0","25","50","75"), boxwex=0.5)

# 'localities'
boxplot(c(localities.0.3sites[,3]), localities.25.3sites[,3], localities.50.3sites[,3], localities.75.3sites[,3], col="orange", notch=T, main="3sites_localities", ylab="Gamma", names=c("0","25","50","75"), boxwex=0.5)
boxplot(c(localities.0.30sites[,3]), localities.25.30sites[,3], localities.50.30sites[,3], localities.75.30sites[,3], col="orange", notch=T, main="30sites_localities", ylab="Gamma", names=c("0","25","50","75"), boxwex=0.5)
boxplot(c(localities.0.300sites[,3]), localities.25.300sites[,3], localities.50.300sites[,3], localities.75.300sites[,3], col="orange", notch=T, main="300sites_localities", ylab="Gamma", names=c("0","25","50","75"), boxwex=0.5)

# 'taphonomy'
boxplot(c(taphonomy.0.3sites[,3]), taphonomy.25.3sites[,3], taphonomy.50.3sites[,3], taphonomy.75.3sites[,3], col="orange", notch=T, main="3sites_taphonomy", ylab="Gamma", names=c("0","25","50","75"), boxwex=0.5)
boxplot(c(taphonomy.0.30sites[,3]), taphonomy.25.30sites[,3], taphonomy.50.30sites[,3], taphonomy.75.30sites[,3], col="orange", notch=T, main="30sites_taphonomy", ylab="Gamma", names=c("0","25","50","75"), boxwex=0.5)
boxplot(c(taphonomy.0.300sites[,3]), taphonomy.25.300sites[,3], taphonomy.50.300sites[,3], taphonomy.75.300sites[,3], col="orange", notch=T, main="300sites_taphonomy", ylab="Gamma", names=c("0","25","50","75"), boxwex=0.5)

# 'lagerstatten'
boxplot(c(lagerstatten.0.3sites[,3]), lagerstatten.25.3sites[,3], lagerstatten.50.3sites[,3], lagerstatten.75.3sites[,3], col="orange", notch=T, main="3sites_lagerstatten", ylab="Gamma", names=c("0","25","50","75"), boxwex=0.5)
boxplot(c(lagerstatten.0.30sites[,3]), lagerstatten.25.30sites[,3], lagerstatten.50.30sites[,3], lagerstatten.75.30sites[,3], col="orange", notch=T, main="30sites_lagerstatten", ylab="Gamma", names=c("0","25","50","75"), boxwex=0.5)
boxplot(c(lagerstatten.0.300sites[,3]), lagerstatten.25.300sites[,3], lagerstatten.50.300sites[,3], lagerstatten.75.300sites[,3], col="orange", notch=T, main="300sites_lagerstatten", ylab="Gamma", names=c("0","25","50","75"), boxwex=0.5)

# 'castings'
boxplot(c(castings.0.3sites[,3]), castings.25.3sites[,3], castings.50.3sites[,3], castings.75.3sites[,3], col="orange", notch=T, main="3sites_castings", ylab="Gamma", names=c("0","25","50","75"), boxwex=0.5)
boxplot(c(castings.0.30sites[,3]), castings.25.30sites[,3], castings.50.30sites[,3], castings.75.30sites[,3], col="orange", notch=T, main="30sites_castings", ylab="Gamma", names=c("0","25","50","75"), boxwex=0.5)
boxplot(c(castings.0.300sites[,3]), castings.25.300sites[,3], castings.50.300sites[,3], castings.75.300sites[,3], col="orange", notch=T, main="300sites_castings", ylab="Gamma", names=c("0","25","50","75"), boxwex=0.5)

################################################################################################################